//
//  CJBookReader.h
//  CJBookReader
//
//  Created by lidi on 2017/10/31.
//  Copyright © 2017年 lidi. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CJBookReader.
FOUNDATION_EXPORT double CJBookReaderVersionNumber;

//! Project version string for CJBookReader.
FOUNDATION_EXPORT const unsigned char CJBookReaderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CJBookReader/PublicHeader.h>

/// 导航栏扩展
#import <CJBookReader/UINavigationController+FDFullscreenPopGesture.h>

/// 小说阅读效果控制器 (无效果,覆盖)
#import <CJBookReader/DZMCoverController.h>

/// 进度条
#import <CJBookReader/ASValueTrackingSlider.h>

/// 光晕
#import <CJBookReader/UIView+YGPulseView.h>

//解压
#import <CJBookReader/ZipArchive.h>

//HTML
#import <CJBookReader/NSString+HTML.h>

//MD5
#import <CJBookReader/NSString+md5.h>

/// 零时使用用于阻挡的 跟项目无关
#import <CJBookReader/MBProgressHUD+DZM.h>
#import <CJBookReader/MBProgressHUD.h>

