//
//  CJPayView.swift
//  AHQBookRead
//
//  Created by lidi on 2017/10/29.
//  Copyright © 2017年 ahq. All rights reserved.
//

import UIKit

class CJPayView: UIView {

    private var txtBook:CJBook?
    private var txtStartChapterIndex = 0
    private var txtPriceInfo = JSONObject()
    private var payChapterCount = 10
    private var buyTxtSuccessCallback:((_ startIndex:Int,_ count:Int)->Void)?
    
    private var epubBook:CJBook?
    private var epubPriceInfo = JSONObject()
    private var buyEpubSuccessCallback:(()->Void)?
    
    var reChargeHandle:(()->Void)?
    
    private let redColor = UIColor(red: 230.0 / 255.0, green: 86.0 / 255.0, blue: 81.0 / 255.0, alpha: 1)
    
    private lazy var priceLabel = UILabel() //需支付的价格
    private lazy var buttonPay = UIButton(type: .custom)//购买按钮
    
    private lazy var contentView = UIView() //内容
    private lazy var topBar = UIView() //头部
    
    private lazy var chooseCountView = ChooseChapterCountView(frame: CGRect.zero) //选择章节数量

    init(txt:CJBook?,chapterIndex:Int,buyTxtSuccessCallback:((_ startIndex:Int,_ count:Int)->Void)?) {
        super.init(frame: CGRect.zero)
        self.txtBook = txt
        self.txtStartChapterIndex = chapterIndex
        self.buyTxtSuccessCallback = buyTxtSuccessCallback
        self.initViews()
    }
    
    init(epub:CJBook?,buyEpubSuccessCallback:(()->Void)?) {
        super.init(frame: CGRect.zero)
        self.epubBook = epub
        self.buyEpubSuccessCallback = buyEpubSuccessCallback
        self.initViews()
    }
    
    private func initViews() {
        self.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.3)
        //底部
        let bottomView = UIView()
        bottomView.backgroundColor = UIColor.white
        self.addSubview(bottomView)
        bottomView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(50.0)
        }
        
        let labelPriceTag = UILabel()
        labelPriceTag.text = "需支付:"
        labelPriceTag.textColor = UIColor.black
        labelPriceTag.textAlignment = .center
        labelPriceTag.font = UIFont.systemFont(ofSize: 14.0)
        bottomView.addSubview(labelPriceTag)
        labelPriceTag.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15.0)
            make.centerY.equalToSuperview()
        }
        
        self.priceLabel.textColor = self.redColor
        self.priceLabel.font = UIFont.systemFont(ofSize: 14.0)
        bottomView.addSubview(self.priceLabel)
        self.priceLabel.snp.makeConstraints { (make) in
            make.left.equalTo(labelPriceTag.snp.right).offset(15.0)
            make.centerY.equalToSuperview()
        }
        
        self.buttonPay.setTitle("确认", for: .normal)
        self.buttonPay.backgroundColor = self.redColor
        self.buttonPay.setTitleColor(UIColor.white, for: .normal)
        self.buttonPay.layer.cornerRadius = 2.0
        self.buttonPay.layer.masksToBounds = true
        self.buttonPay.titleLabel?.font = UIFont.systemFont(ofSize: 15.0)
        self.buttonPay.addTarget(self, action: #selector(self.pay(sender:)), for: .touchUpInside)
        bottomView.addSubview(self.buttonPay)
        self.buttonPay.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-25.0)
            make.centerY.equalToSuperview()
            make.width.equalTo(90.0)
            make.height.equalTo(35.0)
        }
        
        self.contentView.backgroundColor = UIColor(red: 245.0 / 255.0, green: 248.0 / 255.0, blue: 250.0 / 255.0, alpha: 1)
        self.addSubview(self.contentView)
        self.contentView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalTo(bottomView.snp.top)
        }
        //contentView占位
        let tempView = UIView()
        tempView.backgroundColor = UIColor.clear
        self.contentView.addSubview(tempView)
        tempView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
            make.height.equalTo(75.0)
        }
        
        self.topBar.backgroundColor = UIColor.white
        self.addSubview(self.topBar)
        self.topBar.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalTo(self.contentView.snp.top)
            make.height.equalTo(44.0)
        }
        
        let line = UIView()
        line.backgroundColor = UIColor.lightGray
        self.topBar.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(0.5)
        }
        
//        let buttonClose = UIButton(type: .custom)
//        buttonClose.setTitle("关闭", for: .normal)
//        buttonClose.setTitleColor(UIColor.black, for: .normal)
//        buttonClose.frame = CGRect(x: UIScreen.main.width - 44.0, y: 0, width: 44.0, height: 43.5)
//        self.topBar.addSubview(buttonClose)
        
        let labelBookName = UILabel()
        if let book = self.epubBook {
            labelBookName.text = book.epubBookInfo.book_name
        }
        if let book = self.txtBook {
            labelBookName.text = book.txtBookInfo.book_name
        }
        labelBookName.textAlignment = .center
        self.topBar.addSubview(labelBookName)
        labelBookName.frame = CGRect(x: 44.0, y: 0, width: UIScreen.main.width - 88.0, height: 43.5)
        labelBookName.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
        }
        
        let topMask = UIView()
        self.addSubview(topMask)
        topMask.snp.makeConstraints { (make) in
            make.left.right.top.equalToSuperview()
            make.bottom.equalTo(self.topBar.snp.top)
        }
        topMask.backgroundColor = UIColor.clear
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.close(sender:)))
        topMask.addGestureRecognizer(tap)
        
        self.chooseCountView.countChangeCallback = {[weak self] (count) in
            if let book = self?.txtBook,let index = self?.txtStartChapterIndex {
                
                self?.payChapterCount = count
                
                MBProgressHUD.showMessage("")
                
                let startChapter = book.txtChapterList[index]
                _ = Router._fetchTxtPrice(book_id: book.txtBookInfo.book_id, ch_id: startChapter.ch_id, count: count).request({[weak self] (response) in
                    
                    MBProgressHUD.hide()
                    
                    if case .success(let res,_) = response {
                        if let res_ = res {
                            self?.txtPriceInfo = res_
                            self?.refresh()
                        }
                    }
                })
                
            }
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func show() {
        self.frame = UIScreen.main.bounds
        UIApplication.shared.keyWindow?.addSubview(self)
        
        if let book = self.txtBook {
            
            let startChapter = book.txtChapterList[self.txtStartChapterIndex]
            _ = Router._fetchTxtPrice(book_id: book.txtBookInfo.book_id, ch_id: startChapter.ch_id, count: self.payChapterCount).request({[weak self] (response) in
                
                if case .success(let res,_) = response {
                    if let res_ = res {
                        self?.txtPriceInfo = res_
                        self?.refresh()
                    }
                }
                
                if case .failure = response {
                    self?.refresh()
                }

            })
            
        }
        
        if let book = self.epubBook {
            _ = Router._fetchEpubPrice(book_id: book.epubBookInfo.book_id).request({[weak self] (response) in
                
                if case .success(let res,_) = response {
                    if let res_ = res {
                        self?.epubPriceInfo = res_
                        self?.refresh()
                    }
                }
                
                if case .failure = response {
                    self?.refresh()
                }
                
            })
        }
    }

    func refresh() {
        
        //购买图书
        for subview in self.contentView.subviews {
            subview.removeFromSuperview()
        }
        
        
        if let book = self.epubBook {
            
            var balance = 0
            if let balance_ = self.epubPriceInfo["balance"] as? Int {
                balance = balance_
            }
            
            var price = 0
            var money = 0.0
            if let price_ = self.epubPriceInfo["cost"] as? Double {
                money = price_
                price = Int(money * 100)
            }

            self.priceLabel.text = "\(price)长江币"
            
            let labelMoney = UILabel()
            labelMoney.text = "余额: \(balance)长江币"
            labelMoney.font = UIFont.systemFont(ofSize: 13.0)
            labelMoney.textColor = UIColor.lightGray
            self.contentView.addSubview(labelMoney)
            labelMoney.snp.makeConstraints({ (make) in
                make.left.equalToSuperview().offset(15.0)
                make.bottom.equalToSuperview().offset(-10.0)
                make.right.equalToSuperview().offset(15.0)
            })
            
            let labelPrice = UILabel()
            labelPrice.font = UIFont.systemFont(ofSize: 13.0)
            self.contentView.addSubview(labelPrice)
            labelPrice.snp.makeConstraints({ (make) in
                if balance >= price {
                    make.top.equalToSuperview().offset(10.0)
                }
                make.left.equalToSuperview().offset(15.0)
                make.bottom.equalTo(labelMoney.snp.top).offset(-5.0)
                make.right.equalToSuperview().offset(15.0)
            })
            
            let priceString = NSMutableAttributedString()
            priceString.append(NSAttributedString(string: "价格: ", attributes: [NSForegroundColorAttributeName:UIColor.lightGray]))
            priceString.append(NSAttributedString(string: "\(money)元", attributes: [NSForegroundColorAttributeName:self.redColor]))
            priceString.append(NSAttributedString(string: "=\(price)长江币", attributes: [NSForegroundColorAttributeName:UIColor.lightGray]))
            labelPrice.attributedText = priceString
            
            if balance >= price {
                //钱够
                self.buttonPay.setTitle("确定", for: .normal)
            } else {
                //钱不够
                self.buttonPay.setTitle("充值", for: .normal)
                
                let noticeLabel = UILabel()
                noticeLabel.textColor = self.redColor
                noticeLabel.font = UIFont.boldSystemFont(ofSize: 13.0)
                noticeLabel.text = "当前余额不足，请充值后购买"
                self.contentView.addSubview(noticeLabel)
                noticeLabel.snp.makeConstraints({ (make) in
                    make.top.equalToSuperview().offset(10.0)
                    make.left.equalToSuperview().offset(15.0)
                    make.bottom.equalTo(labelPrice.snp.top).offset(-5.0)
                    make.right.equalToSuperview().offset(15.0)
                })
            }
        }
        
        if let book = self.txtBook {
            
            var balance = 0
            if let balance_ = self.txtPriceInfo["balance"] as? Int {
                balance = balance_
            }
            
            var price = 0
            if let price_ = self.txtPriceInfo["price"] as? Int {
                price = price_
            }
            
            self.priceLabel.text = "\(price)长江币"
            
            let labelMoney = UILabel()
            labelMoney.text = "余额: \(balance)长江币"
            labelMoney.font = UIFont.systemFont(ofSize: 13.0)
            labelMoney.textColor = UIColor.lightGray
            self.contentView.addSubview(labelMoney)
            labelMoney.snp.makeConstraints({ (make) in
                make.left.equalToSuperview().offset(15.0)
                make.bottom.equalToSuperview().offset(-10.0)
                make.right.equalToSuperview().offset(15.0)
            })
            
            let labelPrice = UILabel()
            labelPrice.font = UIFont.systemFont(ofSize: 13.0)
            self.contentView.addSubview(labelPrice)
            labelPrice.snp.makeConstraints({ (make) in
                make.left.equalToSuperview().offset(15.0)
                make.bottom.equalTo(labelMoney.snp.top).offset(-5.0)
                make.right.equalToSuperview().offset(15.0)
            })
            
            let priceString = NSMutableAttributedString()
            priceString.append(NSAttributedString(string: "价格: ", attributes: [NSForegroundColorAttributeName:UIColor.lightGray]))
            priceString.append(NSAttributedString(string: "\(price)长江币", attributes: [NSForegroundColorAttributeName:self.redColor]))
            labelPrice.attributedText = priceString
            
            //起始章节
            let startChapter = book.txtChapterList[self.txtStartChapterIndex]
            let labelChapterName = UILabel()
            labelChapterName.text = "起始章节: \(startChapter.ch_name) (已购章节不扣费)"
            labelChapterName.font = UIFont.systemFont(ofSize: 13.0)
            labelChapterName.numberOfLines = 0
            labelChapterName.textColor = UIColor.lightGray
            self.contentView.addSubview(labelChapterName)
            labelChapterName.snp.makeConstraints({ (make) in
                make.left.equalToSuperview().offset(15.0)
                make.bottom.equalTo(labelPrice.snp.top).offset(-5.0)
                make.right.equalToSuperview().offset(15.0)
            })
            
            var preView = labelChapterName
            
            if balance >= price {
                //钱够
                self.buttonPay.setTitle("确定", for: .normal)
            } else {
                //钱不够
                self.buttonPay.setTitle("充值", for: .normal)
                
                let noticeLabel = UILabel()
                noticeLabel.textColor = self.redColor
                noticeLabel.font = UIFont.boldSystemFont(ofSize: 13.0)
                noticeLabel.text = "当前余额不足，请充值后购买"
                self.contentView.addSubview(noticeLabel)
                noticeLabel.snp.makeConstraints({ (make) in
                    make.left.equalToSuperview().offset(15.0)
                    make.bottom.equalTo(labelChapterName.snp.top).offset(-5.0)
                    make.right.equalToSuperview().offset(15.0)
                })
                
                preView = noticeLabel
            }
            
            self.contentView.addSubview(self.chooseCountView)
            self.chooseCountView.snp.makeConstraints({ (make) in
                make.left.equalToSuperview().offset(15.0)
                make.right.equalToSuperview().offset(-15.0)
                make.bottom.equalTo(preView.snp.top).offset(-10.0)
                make.top.equalToSuperview().offset(10.0)
                make.height.equalTo(110.0)
            })
            
        }
    
    }
    
    @objc private func close(sender:Any) {
        self.removeFromSuperview()
    }
    
    @objc func pay(sender:Any) {
        
        if let book = epubBook {
            
            var balance = 0
            if let balance_ = self.epubPriceInfo["balance"] as? Int {
                balance = balance_
            }
            
            var price = 0
            var money = 0.0
            if let price_ = self.epubPriceInfo["cost"] as? Double {
                money = price_
                price = Int(money * 100)
            }
            if balance >= price {
                //购买
                MBProgressHUD.showMessage("正在购买")
                _ = Router._buyEpub(book_id: book.epubBookInfo.book_id).request({[weak self] (response) in
                    MBProgressHUD.hide()

                    if case .success(_,let message) = response {
                        MBProgressHUD.showSuccess(message, completion: {
                            //回调支付结果
                            self?.buyEpubSuccessCallback?()
                            self?.close(sender: "")
                        })
                    }
                    
                    if case .failure(let message,_) = response {
                        MBProgressHUD.showError(message)
                    }
                    
                })
            } else {
                //跳转充值
                self.close(sender: "")
                self.reChargeHandle?()
            }
        }
        
        if let book = self.txtBook {
            
            var balance = 0
            if let balance_ = self.txtPriceInfo["balance"] as? Int {
                balance = balance_
            }
            
            var price = 0
            if let price_ = self.txtPriceInfo["price"] as? Int {
                price = price_
            }
            
            if balance >= price {
                //购买
                MBProgressHUD.showMessage("正在购买")
                
                let startChapter = book.txtChapterList[self.txtStartChapterIndex]
                
                _ = Router._buyTxt(book_id: book.txtBookInfo.book_id, ch_id:startChapter.ch_id , count: self.payChapterCount).request({[weak self] (response) in
                    
                    MBProgressHUD.hide()
                    
                    if case .success(_,let message) = response {
                        
                        MBProgressHUD.showSuccess(message, completion: {
                            //回调支付结果
                            if let startIndex = self?.txtStartChapterIndex,let count = self?.payChapterCount {
                                self?.buyTxtSuccessCallback?(startIndex,count)
                            }
                            self?.close(sender: "")
                        })
                        
                    }
                    
                    if case .failure(let message,_) = response {
                        MBProgressHUD.showError(message)
                    }
                })
            } else {
                //跳转充值
                self.close(sender: "")
                self.reChargeHandle?()
            }
            
        }
        
    }
    
    class ChooseChapterCountView: UIView {
        
        enum Status {
            case custom
            case Buy10
            case Buy40
            case Buy100
        }
        
        var countChangeCallback:((_ count:Int) -> Void)?
        private var count = 10
        private var status = Status.Buy10 {
            didSet {
                self.button10.layer.borderColor = UIColor.lightGray.cgColor
                self.button40.layer.borderColor = UIColor.lightGray.cgColor
                self.button100.layer.borderColor = UIColor.lightGray.cgColor

                switch self.status {
                case .Buy10:
                    self.button10.layer.borderColor = self.redColor.cgColor
                case .Buy40:
                    self.button40.layer.borderColor = self.redColor.cgColor
                case .Buy100:
                    self.button100.layer.borderColor = self.redColor.cgColor
                default: break
                }
            }
        }

        private let redColor = UIColor(red: 230.0 / 255.0, green: 86.0 / 255.0, blue: 81.0 / 255.0, alpha: 1)
        private var buttonMinus = UIButton(type: .custom)
        private var buttonPlus = UIButton(type: .custom)
        private var button10 = UIButton(type: .custom)
        private var button40 = UIButton(type: .custom)
        private var button100 = UIButton(type: .custom)
        private var labelCount = UILabel()

        func refresh() {
            self.labelCount.text = "\(self.count)章"
        }
        
        @objc private func buttonClick(sender:UIButton) {
            switch sender.tag {
            case -1:
                self.count += -1
                self.status = .custom
            case 1:
                self.count += 1
                self.status = .custom
            case 10:
                self.count = 10
                self.status = .Buy10
            case 40:
                self.count = 40
                self.status = .Buy40
            case 100:
                self.count = 100
                self.status = .Buy100
            default:
                break
            }
            if self.count <= 0 {
                self.count = 1
            }
            
            self.countChangeCallback?(self.count)
            self.refresh()
        }
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            self.backgroundColor = UIColor.clear
            
            let customView = UIView()
            
            self.buttonMinus.setTitle("-", for: .normal)
            self.buttonPlus.setTitle("+", for: .normal)
            self.button10.setTitle("10章", for: .normal)
            self.button40.setTitle("40章", for: .normal)
            self.button100.setTitle("100章", for: .normal)
            
            self.buttonMinus.setTitleColor(UIColor.darkGray, for: .normal)
            self.buttonPlus.setTitleColor(UIColor.darkGray, for: .normal)
            self.button10.setTitleColor(UIColor.darkGray, for: .normal)
            self.button40.setTitleColor(UIColor.darkGray, for: .normal)
            self.button100.setTitleColor(UIColor.darkGray, for: .normal)
            
            customView.layer.cornerRadius = 5.0
            customView.layer.masksToBounds = true
            customView.layer.borderColor = UIColor.lightGray.cgColor
            customView.layer.borderWidth = 0.5
            self.button10.layer.cornerRadius = 5.0
            self.button10.layer.masksToBounds = true
            self.button10.layer.borderColor = self.redColor.cgColor
            self.button10.layer.borderWidth = 0.5
            self.button40.layer.cornerRadius = 5.0
            self.button40.layer.masksToBounds = true
            self.button40.layer.borderColor = UIColor.lightGray.cgColor
            self.button40.layer.borderWidth = 0.5
            self.button100.layer.cornerRadius = 5.0
            self.button100.layer.masksToBounds = true
            self.button100.layer.borderColor = UIColor.lightGray.cgColor
            self.button100.layer.borderWidth = 0.5
            
            self.buttonMinus.tag = -1
            self.buttonPlus.tag = 1
            self.button10.tag = 10
            self.button40.tag = 40
            self.button100.tag = 100
            
            self.buttonMinus.backgroundColor = UIColor.white
            self.buttonPlus.backgroundColor = UIColor.white
            self.button10.backgroundColor = UIColor.white
            self.button40.backgroundColor = UIColor.white
            self.button100.backgroundColor = UIColor.white
            
            customView.addSubview(self.buttonMinus)
            customView.addSubview(self.buttonPlus)
            customView.addSubview(self.labelCount)
            self.buttonMinus.titleLabel?.font = UIFont.systemFont(ofSize: 25.0)
            self.buttonMinus.snp.makeConstraints { (make) in
                make.left.top.bottom.equalToSuperview()
                make.width.equalTo(50.0)
            }
            self.buttonPlus.titleLabel?.font = UIFont.systemFont(ofSize: 25.0)
            self.buttonPlus.snp.makeConstraints { (make) in
                make.right.top.bottom.equalToSuperview()
                make.width.equalTo(50.0)
            }
            self.labelCount.textAlignment = .center
            self.labelCount.snp.makeConstraints { (make) in
                make.left.equalTo(self.buttonMinus.snp.right)
                make.right.equalTo(self.buttonPlus.snp.left)
                make.centerY.equalToSuperview()
            }
            
            let lineLeft = UIView()
            let lineRight = UIView()
            lineLeft.backgroundColor = UIColor.lightGray
            lineRight.backgroundColor = UIColor.lightGray
            customView.addSubview(lineLeft)
            customView.addSubview(lineRight)
            lineLeft.snp.makeConstraints { (make) in
                make.left.equalTo(self.buttonMinus.snp.right)
                make.top.bottom.equalToSuperview()
                make.width.equalTo(0.5)
            }
            lineRight.snp.makeConstraints { (make) in
                make.right.equalTo(self.buttonPlus.snp.left)
                make.top.bottom.equalToSuperview()
                make.width.equalTo(0.5)
            }

            self.addSubview(customView)
            customView.snp.makeConstraints { (make) in
                make.left.top.equalToSuperview()
            }
            self.addSubview(self.button10)
            self.button10.snp.makeConstraints { (make) in
                make.left.equalTo(customView.snp.right).offset(10.0)
                make.width.equalTo(customView.snp.width)
                make.right.top.equalToSuperview()
            }
            self.addSubview(self.button40)
            self.button40.snp.makeConstraints { (make) in
                make.left.bottom.equalToSuperview()
                make.height.equalTo(customView.snp.height)
                make.top.equalTo(customView.snp.bottom).offset(10.0)
            }
            self.addSubview(self.button100)
            self.button100.snp.makeConstraints { (make) in
                make.height.equalTo(self.button10.snp.height)
                make.width.equalTo(self.button40.snp.width)
                make.left.equalTo(self.button40.snp.right).offset(10.0)
                make.top.equalTo(self.button10.snp.bottom).offset(10.0)
                make.right.bottom.equalToSuperview()
            }
            
            self.buttonMinus.addTarget(self, action: #selector(self.buttonClick(sender:)), for: .touchUpInside)
            self.buttonPlus.addTarget(self, action: #selector(self.buttonClick(sender:)), for: .touchUpInside)
            self.button10.addTarget(self, action: #selector(self.buttonClick(sender:)), for: .touchUpInside)
            self.button40.addTarget(self, action: #selector(self.buttonClick(sender:)), for: .touchUpInside)
            self.button100.addTarget(self, action: #selector(self.buttonClick(sender:)), for: .touchUpInside)
            self.refresh()
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
        
    }
    
}
