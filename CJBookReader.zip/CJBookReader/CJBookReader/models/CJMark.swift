//
//  CJMark.swift
//  AHQBookRead
//
//  Created by lidi on 2017/10/27.
//  Copyright © 2017年 ahq. All rights reserved.
//

import UIKit

//书签
class CJMark: NSObject , NSSecureCoding {
    
    var mark_id = ""
    var chapter_id = ""
    var name = ""
    var content = ""
    var create_time:TimeInterval = 0.0
    var location = 0  //txt  位置。 epub page
    
    override init() {
        super.init()
    }
    
    //MARK: - NSSecureCoding
    static var supportsSecureCoding: Bool = true
    
    required init?(coder aDecoder: NSCoder) {
        super.init()
        
        self.create_time = aDecoder.decodeDouble(forKey: "create_time")
        self.location = aDecoder.decodeInteger(forKey: "location")
        
        if let value = aDecoder.decodeObject(forKey: "mark_id") as? String {
            self.mark_id = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "chapter_id") as? String {
            self.chapter_id = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "content") as? String {
            self.content = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "name") as? String {
            self.name = value
        }
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(self.mark_id,forKey:"mark_id")
        aCoder.encode(self.chapter_id, forKey: "chapter_id")
        aCoder.encode(self.name, forKey: "name")
        aCoder.encode(self.content, forKey: "content")
        aCoder.encode(self.create_time, forKey: "create_time")
        aCoder.encode(self.location, forKey: "location")
    }
    
    ///判断是否相等
    override func isEqual(_ object: Any?) -> Bool {
        if let obj = object as? CJMark {
            return self.mark_id == obj.mark_id
        } else {
            return false
        }
    }
}
