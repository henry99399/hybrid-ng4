//
//  CJBook.swift
//  AHQBookRead
//
//  Created by lidi on 2017/10/26.
//  Copyright © 2017年 ahq. All rights reserved.
//

import UIKit

class CJBook: NSObject , NSSecureCoding {
    
    enum BookType {
        case txt
        case epub
    }
    
    var bookType = BookType.txt //图书类型
    
    var record = CJRecord() //阅读记录
    
    var marks = [CJMark]() //书签列表
    
    var isLocal = true //是否离线
    
    /// 当前书签(用于记录使用)
    fileprivate var currentMark:CJMark?
    
    override init() {
        super.init()
        
        self.readRecord()
        self.readMarks()
        self.readChapters()
    }
    
    //网文部分
    var txtBookInfo = CJTxtBookInfo()
    var txtChapterList = [CJTxtChapter]()
    
    init(txtJson:JSONObject?) {
        super.init()
        
        self.bookType = .txt
        
        self.txtBookInfo = CJTxtBookInfo(txtJson: txtJson?["info"] as? JSONObject)
        
        var chapterList_ = [CJTxtChapter]()
        if let chapterListObj = txtJson?["chapters"] as? JSONObject ,
            let chaptersObj = chapterListObj["chapters"] as? [JSONObject] {
            
            for index in 0 ..< chaptersObj.count {
                let chapterObj = chaptersObj[index]
                let chapter = CJTxtChapter(txtJson: chapterObj)
                chapterList_.append(chapter)
            }
        }
        self.txtChapterList = chapterList_
        
        self.readRecord()
        self.readMarks()
        self.readChapters()
    }
    
    //epub
    var epubBookInfo = CJEpubBookInfo()
    var epubChapterList = [CJEpubChapter]()
    
    init(epubJson:JSONObject?) {
        super.init()
        
        self.bookType = .epub
        
        self.epubBookInfo = CJEpubBookInfo(epubJson: epubJson?["info"] as? JSONObject)
        
        var chapterList_ = [CJEpubChapter]()
        if let chaptersObj = epubJson?["chapters"] as? [JSONObject] {
            
            var cnIndex = 0
            for index in 0 ..< chaptersObj.count {
                let chapterObj = chaptersObj[index]
                let chapter = CJEpubChapter(epubJson: chapterObj)
                chapter.ch_index = cnIndex
                chapterList_.append(chapter)
                cnIndex += 1

                for i in 0 ..< chapter.child.count {
                    let chapter_ = chapter.child[i]
                    chapter_.ch_index = cnIndex
                    chapterList_.append(chapter_)
                    cnIndex += 1
                }
                
            }
        }
        self.epubChapterList = chapterList_
        
        self.readRecord()
        self.readMarks()
        self.readChapters()
    }
    
    //MARK: - NSSecureCoding
    static var supportsSecureCoding: Bool = true
    
    required init?(coder aDecoder: NSCoder) {
        super.init()
        
        let type = aDecoder.decodeInteger(forKey: "bookType")
        if type == 1 {
            self.bookType = .epub
        } else {
            self.bookType = .txt
        }
        
        if let value = aDecoder.decodeObject(forKey: "record") as? CJRecord {
            self.record = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "marks") as? [CJMark] {
            self.marks = value
        }
        
        self.isLocal = aDecoder.decodeBool(forKey: "isLocal")
        
        if let value = aDecoder.decodeObject(forKey: "txtBookInfo") as? CJTxtBookInfo {
            self.txtBookInfo = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "txtChapterList") as? [CJTxtChapter] {
            self.txtChapterList = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "epubBookInfo") as? CJEpubBookInfo {
            self.epubBookInfo = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "epubChapterList") as? [CJEpubChapter] {
            self.epubChapterList = value
        }
    }
    
    func encode(with aCoder: NSCoder) {
        let type = self.bookType == .txt ? 0 : 1
        aCoder.encode(type, forKey: "bookType")
        aCoder.encode(self.record, forKey: "record")
        aCoder.encode(self.marks, forKey: "marks")
        aCoder.encode(self.isLocal, forKey: "isLocal")
        aCoder.encode(self.txtBookInfo, forKey: "txtBookInfo")
        aCoder.encode(self.txtChapterList, forKey: "txtChapterList")
        aCoder.encode(self.epubBookInfo, forKey: "epubBookInfo")
        aCoder.encode(self.epubChapterList, forKey: "epubChapterList")
    }
    
    deinit {
        self.saveRecord()
        self.saveMarks()
        self.saveChapters()
    }
}

extension CJBook {
    
    func addRemark(readRecord:CJRecord,markId:String) {
        //添加书签
        if self.bookType == .txt {
            if let chapter = readRecord.txtChapter {
                
                let range = chapter.pageRanges[readRecord.page]
                
                let mark = CJMark()
                mark.mark_id = markId
                mark.create_time = NSDate().timeIntervalSince1970
                mark.chapter_id = chapter.ch_id
                mark.content = chapter.content.substring(range)
                mark.location = range.location
                mark.name = chapter.ch_name
                
                self.marks.insert(mark, at: 0)
            }
        }
        
        if self.bookType == .epub {
            if let chapter = readRecord.epubChapter {
                let mark = CJMark()
                mark.mark_id = markId
                mark.create_time = NSDate().timeIntervalSince1970
                mark.chapter_id = chapter.id
                mark.content = chapter.contentFor(page: readRecord.page)
                mark.location = record.page
                mark.name = chapter.name
                
                self.marks.insert(mark, at: 0)
            }
        }
        
        self.saveMarks()
    }
    
    func deleteReadmark(readMark:CJMark? = nil,index:Int? = nil,callback:(()->Void)? ) {
        
        var markIndex = self.marks.startIndex
        
        if let mark_ = readMark {
            //删除书签
            if let index_ = self.marks.index(of: mark_) {
                markIndex = index_
            }

        }

        if let index_ = index {
            markIndex = index_
        }
        
        if let mark_ = self.currentMark {
            if let index_ = self.marks.index(of: mark_) {
                markIndex = index_
            }
        }
        
        let mark = self.marks[markIndex]
        
        MBProgressHUD.showMessage()
        _ = Router._deleteBookMark(marks: mark.mark_id).request {[weak self] (response) in
            MBProgressHUD.hide()
            if case .success = response {
                self?.marks.remove(at: markIndex)
                callback?()
                self?.saveMarks()
            }
            if case .failure(let message,_) = response {
                MBProgressHUD.showError(message)
            }
        }
        
    }
    
    func isMarkExist(readRecord:CJRecord) -> Bool {
        
        self.currentMark = nil
        
        if self.bookType == .txt {
            if let chapter = readRecord.txtChapter {
                let range = chapter.pageRanges[readRecord.page]
                for mark in self.marks {
                    if mark.chapter_id == chapter.ch_id {
                        let location = mark.location
                        if location >= range.location && location < (range.location + range.length) {
                            self.currentMark = mark
                            return true
                        }
                    }
                }
                return false
            } else {
                return false
            }
        } else {
            if let chapter = readRecord.epubChapter {
                let page = readRecord.page
                for mark in self.marks {
                    if mark.chapter_id == chapter.id && mark.location == page {
                        self.currentMark = mark
                        return true
                    }
                }
                return false
            } else {
                return false
            }
        }
    }
}

extension CJBook {
    
    //保存书签
    fileprivate func saveMarks() {
        var bookId = ""
        if self.bookType == .txt {
            bookId = self.txtBookInfo.book_id
        }
        if self.bookType == .epub {
            bookId = self.epubBookInfo.book_id
        }
        
        if bookId.isEmpty {
            return
        }
        
        ///保存书签
        let cachePath = FileManager.default.cachePathFor(userId: CJUserInfo.shared.userId)
        let markPath = cachePath + "/" + "bookreadmarks_" + bookId
        NSKeyedArchiver.archiveRootObject(self.marks, toFile: markPath)
    }
    
    //保存章节
    func saveChapters() {
        ///保存阅读记录
        var bookId = ""
        if self.bookType == .txt {
            bookId = self.txtBookInfo.book_id
        }
        if self.bookType == .epub {
            bookId = self.epubBookInfo.book_id
        }
        
        if bookId.isEmpty {
            return
        }
        
        ///保存章节内容
        var txtContents = JSONObject()
        for cp in self.txtChapterList {
            if !cp.content.isEmpty {
                txtContents[cp.ch_id] = cp.content
            }
        }
        for cp in self.epubChapterList {
            if !cp.content.isEmpty {
                txtContents[cp.id] = cp.content
            }
        }
        
        let cachePath = FileManager.default.cachePathFor(userId: CJUserInfo.shared.userId)
        let txtChapterPath = cachePath + "/" + "bookreadtxtchapters_" + bookId
        NSKeyedArchiver.archiveRootObject(txtContents, toFile: txtChapterPath)
    }
    
    func saveRecord() {
        ///保存阅读记录
        var bookId = ""
        if self.bookType == .txt {
            bookId = self.txtBookInfo.book_id
        }
        if self.bookType == .epub {
            bookId = self.epubBookInfo.book_id
        }
        
        if bookId.isEmpty {
            return
        }
        
        let cachePath = FileManager.default.cachePathFor(userId: CJUserInfo.shared.userId)
        let recordPath = cachePath + "/" + "bookreadrecord_" + bookId
        NSKeyedArchiver.archiveRootObject(self.record, toFile: recordPath)
    }
    
    //读取书签
    fileprivate func readMarks() {
        var bookId = ""
        if self.bookType == .txt {
            bookId = self.txtBookInfo.book_id
        }
        if self.bookType == .epub {
            bookId = self.epubBookInfo.book_id
        }
        
        if bookId.isEmpty {
            return
        }
        
        let cachePath = FileManager.default.cachePathFor(userId: CJUserInfo.shared.userId)
        let markPath = cachePath + "/" + "bookreadmarks_" + bookId
        if let bookMarks = NSKeyedUnarchiver.unarchiveObject(withFile: markPath) as? [CJMark] {
            self.marks = bookMarks
        }
    }
    
    //读取章节
    fileprivate func readChapters() {
        var bookId = ""
        if self.bookType == .txt {
            bookId = self.txtBookInfo.book_id
        }
        if self.bookType == .epub {
            bookId = self.epubBookInfo.book_id
        }
        
        if bookId.isEmpty {
            return
        }
        
        let cachePath = FileManager.default.cachePathFor(userId: CJUserInfo.shared.userId)
        let txtChapterPath = cachePath + "/" + "bookreadtxtchapters_" + bookId
        if let contents = NSKeyedUnarchiver.unarchiveObject(withFile: txtChapterPath) as? JSONObject {
            for cp in self.txtChapterList {
                if let content = contents[cp.ch_id] as? String , !content.isEmpty {
                    cp.content = content
                    cp.updateFont()
                }
            }
            for cp in self.epubChapterList {
                if let content = contents[cp.id] as? String , !content.isEmpty {
                    cp.content = content
                    cp.updateFont()
                }
            }
        }
    }
    
    ///读取阅读记录
    fileprivate func readRecord() {
        
        var bookId = ""
        if self.bookType == .txt {
            bookId = self.txtBookInfo.book_id
        }
        if self.bookType == .epub {
            bookId = self.epubBookInfo.book_id
        }
        
        if bookId.isEmpty {
            return
        }
        
        let cachePath = FileManager.default.cachePathFor(userId: CJUserInfo.shared.userId)
        let recordPath = cachePath + "/" + "bookreadrecord_" + bookId
        if let record_ = NSKeyedUnarchiver.unarchiveObject(withFile: recordPath) as? CJRecord {
            self.record = record_
        } else {
            if self.txtChapterList.count > 0 {
                let chapter_ = self.txtChapterList[0]
                chapter_.updateFont()
                self.record.txtChapter = chapter_
            }
            if self.epubChapterList.count > 0 {
                let chapter_ = self.epubChapterList[0]
                chapter_.updateFont()
                self.record.epubChapter = chapter_
            }
        }
    }
    
    func uploadRecord() {
        
        //记录阅读记录
        var bookId = ""
        var chapterId = ""
        var schedule = ""
        var bookType = ""
        var bookName = ""
        var bookCover = ""
        var chapterName = ""
        
        if self.bookType == .txt ,let chapter = self.record.txtChapter {
            bookId = self.txtBookInfo.book_id
            chapterId = chapter.ch_id
            bookType = "1"
            bookName = self.txtBookInfo.book_name
            bookCover = self.txtBookInfo.book_cover
            chapterName = chapter.ch_name
            
            //阅读进度
            let chapterIndex = chapter.ch_index
            var progress = CGFloat(chapterIndex + 1) / CGFloat(self.txtChapterList.count)
            progress = progress > 1 ? 1 : progress
            schedule = "\(chapter.ch_id)|\(progress)"
        }
        
        if self.bookType == .epub ,let chapter = self.record.epubChapter {
            bookId = self.epubBookInfo.book_id
            chapterId = chapter.id
            bookType = "2"
            bookName = self.epubBookInfo.book_name
            bookCover = self.epubBookInfo.book_cover
            chapterName = chapter.name
            
            //阅读进度
            let chapterIndex = chapter.ch_index
            var progress = CGFloat(chapterIndex + 1) / CGFloat(self.epubChapterList.count)
            progress = progress > 1 ? 1 : progress
            let progeessString = String(format:"%.2f",progress)
            schedule = "\(chapter.id)|\(progeessString)"
        }
        
        _ = Router._saveUserRecord(book_id: bookId, last_chapter_id: chapterId, schedule: schedule, book_type: bookType, book_name: bookName, book_cover: bookCover, chapter_name: chapterName).request { (response) in
            switch response {
            case .success(_, let message):
                print(message)
            case .failure(let message, _):
                print(message)
            default:break
            }
        }
    }
    
    /// 修改阅读记录为 指定章节ID 指定页码
    func modifyRecord(chapterID:String, page:Int = 0, isUpdateFont:Bool = false, isSave:Bool = false) {
        if self.bookType == .txt,!txtChapterList.isEmpty {
            for cp in self.txtChapterList {
                if cp.ch_id == chapterID {
                    
                    if isUpdateFont {
                        cp.updateFont(isSave: isSave)
                    }
                    
                    self.record.txtChapter = cp
                    self.record.epubChapter = nil
                    self.record.page = page
                    break
                }
            }
        }
        
        if self.bookType == .epub,!epubChapterList.isEmpty {
            for cp in self.epubChapterList {
                if cp.id == chapterID {
                    
                    if isUpdateFont {
                        cp.updateFont(isSave: isSave)
                    }
                    
                    self.record.epubChapter = cp
                    self.record.txtChapter = nil
                    self.record.page = page
                    break
                }
            }
        }
    }
}
