//
//  CJBookInfo.swift
//  AHQBookRead
//
//  Created by lidi on 2017/10/27.
//  Copyright © 2017年 ahq. All rights reserved.
//

import Foundation

class CJTxtBookInfo: NSObject {
    
    var book_author = ""
    var book_cat_name = ""
    var book_cover = ""
    var book_id = ""
    var book_name = ""
    var book_remark = ""
    var create_time = ""
    var is_finish = false
    var update_time = ""
    var word_size = 0
    
    override init() {
        super.init()
    }
    
    //网文
    init(txtJson:JSONObject?) {
        super.init()
        
        if let value = txtJson?["book_author"] as? String {
            self.book_author = value
        }
        if let value = txtJson?["book_cat_name"] as? String {
            self.book_cat_name = value
        }
        if let value = txtJson?["book_cover"] as? String {
            self.book_cover = value
        }
        
        if let value = txtJson?["book_id"] as? Int {
            self.book_id = String(value)
        }
        if let value = txtJson?["book_id"] as? String {
            self.book_id = value
        }
        
        if let value = txtJson?["book_name"] as? String {
            self.book_name = value
        }
        if let value = txtJson?["book_remark"] as? String {
            self.book_remark = value
        }
        if let value = txtJson?["create_time"] as? String {
            self.create_time = value
        }
        
        if let value = txtJson?["is_finish"] as? Int {
            self.is_finish = value > 0
        }
        if let value = txtJson?["is_finish"] as? Bool {
            self.is_finish = value
        }
        
        if let value = txtJson?["update_time"] as? String {
            self.update_time = value
        }
        if let value = txtJson?["word_size"] as? Int {
            self.word_size = value
        }
    }
    
    //MARK: - NSSecureCoding
    static var supportsSecureCoding: Bool = true
    
    required init?(coder aDecoder: NSCoder) {
        super.init()
        
        if let value = aDecoder.decodeObject(forKey: "book_author") as? String {
            self.book_author = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "book_cat_name") as? String {
            self.book_cat_name = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "book_cover") as? String {
            self.book_cover = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "book_id") as? String {
            self.book_id = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "book_name") as? String {
            self.book_name = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "book_remark") as? String {
            self.book_remark = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "create_time") as? String {
            self.create_time = value
        }
        
        self.is_finish = aDecoder.decodeBool(forKey: "is_finish")
        
        if let value = aDecoder.decodeObject(forKey: "update_time") as? String {
            self.update_time = value
        }
        
        self.word_size = aDecoder.decodeInteger(forKey: "word_size")
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(self.book_author, forKey: "book_author")
        aCoder.encode(self.book_cat_name, forKey: "book_cat_name")
        aCoder.encode(self.book_cover, forKey: "book_cover")
        aCoder.encode(self.book_id, forKey: "book_id")
        aCoder.encode(self.book_name, forKey: "book_name")
        aCoder.encode(self.book_remark, forKey: "book_remark")
        aCoder.encode(self.create_time, forKey: "create_time")
        aCoder.encode(self.is_finish, forKey: "is_finish")
        aCoder.encode(self.update_time, forKey: "update_time")
        aCoder.encode(self.word_size, forKey: "word_size")
    }
}

class CJEpubBookInfo: NSObject {
    
    var book_author = ""
    var book_cover = ""
    var book_cover_small = ""
    var book_id = ""
    var book_name = ""
    var book_url = ""
    var schedule = ""
    
    override init() {
        super.init()
    }
    
    init(epubJson:JSONObject?) {
        if let value = epubJson?["book_author"] as? String {
            self.book_author = value
        }
        
        if let value = epubJson?["book_cover"] as? String {
            self.book_cover = value
        }
        if let value = epubJson?["book_cover_small"] as? String {
            self.book_cover_small = value
        }
        
        if let value = epubJson?["book_id"] as? Int {
            self.book_id = String(value)
        }
        if let value = epubJson?["book_id"] as? String {
            self.book_id = value
        }
        
        if let value = epubJson?["book_name"] as? String {
            self.book_name = value
        }
        if let value = epubJson?["book_url"] as? String {
            self.book_url = value
        }
        
        if let value = epubJson?["schedule"] as? String {
            self.schedule = value
        }
    }
    
    //MARK: - NSSecureCoding
    static var supportsSecureCoding: Bool = true
    
    required init?(coder aDecoder: NSCoder) {
        super.init()

        if let value = aDecoder.decodeObject(forKey: "book_author") as? String {
            self.book_author = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "book_cover") as? String {
            self.book_cover = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "book_cover_small") as? String {
            self.book_cover_small = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "book_id") as? String {
            self.book_id = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "book_name") as? String {
            self.book_name = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "book_url") as? String {
            self.book_url = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "schedule") as? String {
            self.schedule = value
        }
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(self.book_author, forKey: "book_author")
        aCoder.encode(self.book_cover, forKey: "book_cover")
        aCoder.encode(self.book_cover_small, forKey: "book_cover_small")
        aCoder.encode(self.book_id, forKey: "book_id")
        aCoder.encode(self.book_name, forKey: "book_name")
        aCoder.encode(self.book_url, forKey: "book_url")
        aCoder.encode(self.schedule, forKey: "schedule")
    }
}
