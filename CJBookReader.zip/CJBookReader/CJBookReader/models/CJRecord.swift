//
//  CJRecord.swift
//  AHQBookRead
//
//  Created by lidi on 2017/10/27.
//  Copyright © 2017年 ahq. All rights reserved.
//

import UIKit

//阅读记录
class CJRecord: NSObject , NSSecureCoding {
    
    var txtChapter:CJTxtChapter?
    var epubChapter:CJEpubChapter?
    
    var page = 0
    
    override init() {
        super.init()
    }
    
    //MARK: - NSSecureCoding
    static var supportsSecureCoding: Bool = true
    
    required init?(coder aDecoder: NSCoder) {
        super.init()
        
        self.page = aDecoder.decodeInteger(forKey: "page")
        
        if let value = aDecoder.decodeObject(forKey: "txtChapter") as? CJTxtChapter {
            self.txtChapter = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "epubChapter") as? CJEpubChapter {
            self.epubChapter = value
        }
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(self.page, forKey: "page")
        aCoder.encode(self.txtChapter, forKey: "txtChapter")
        aCoder.encode(self.epubChapter, forKey: "epubChapter")
    }
}

extension CJRecord {
    //深拷贝
    func copySelf() -> CJRecord {
       let archData = NSKeyedArchiver.archivedData(withRootObject: self)
        if let copy_ = NSKeyedUnarchiver.unarchiveObject(with: archData) as? CJRecord {
            return copy_
        } else {
            return self
        }
    }
}

extension CJRecord {
    /// 刷新字体
    func updateFont(isSave:Bool = false) {
        
        if let txt = self.txtChapter {
            
            txt.updateFont(isSave: isSave)
            if self.page >= txt.pageRanges.count {
                self.page = txt.pageRanges.count - 1
            }
            let location = txt.pageRanges[self.page].location
            self.page = txt.pageFor(location: location)
        }
        
        if let epub = self.epubChapter {
            epub.updateFont(isSave: isSave)
            if self.page >= epub.pageCount {
                self.page = epub.pageCount - 1
            }
        }
    }
}
