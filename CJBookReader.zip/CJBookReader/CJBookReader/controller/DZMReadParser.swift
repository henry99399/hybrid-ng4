//
//  DZMReadParser.swift
//  DZMeBookRead
//
//  Created by 邓泽淼 on 2017/5/12.
//  Copyright © 2017年 DZM. All rights reserved.
//

import UIKit
import CoreText

class DZMReadParser: NSObject {
    
    // MARK: -- 解析文件
    
    /**
     异步线程 解析本地URL
     
     - parameter url: 本地小说文本URL
     
     - parameter complete: 成功返回true  失败返回false
     
     - returns: ReadModel
     */
    class func ParserLocalPath(path:String,complete:((_ readModel:DZMReadModel) ->Void)?) {
       
        DispatchQueue.global().async {
            
            //let readModel = DZMReadParser.ParserLocalURL(url: url)
            let readModel = DZMReadParser.ParserLocalEpub(path: path)

            DispatchQueue.main.async(execute: {()->() in
                
                if complete != nil {complete!(readModel)}
            })
            
        }
    }
    
    //MARK: - 解析epub
    
    /**
     主线程 解析本地 epub URL
     
     - parameter url: URL
     
     - returns: ReadModel
     
     */
    static func ParserLocalEpub(path:String) -> DZMReadModel {
        let bookID = GetFileName(URL(fileURLWithPath: path))
        if !DZMReadModel.IsExistReadModel(bookID: bookID) { //不存在
            // 阅读模型
            let readModel = DZMReadModel.readModel(bookID: bookID)
            
            //解析数据
            let zipPath = self.unZip(path: path) //解压epub文件后的文件路径
            //let opfPath = self.OPFPath(epubPath: zipPath)
            //let readChapterListModels = self.parseOPF(bookID: bookID, opfPath: opfPath)
            
            // 获得章节列表
            //readModel.readChapterListModels = readChapterListModels
            
            // 设置阅读记录 第一个章节 为 "0"
            readModel.modifyReadRecordModel(chapterID: "0")
            
            // 保存
            readModel.save()
            
            // 返回
            return readModel
            
        }else{ // 存在
            // 返回
            return DZMReadModel.readModel(bookID: bookID)
        }
    }
    
    //MARK: - 解压文件路径
    private static func unZip(path:String) -> String? {
        
        let zip = ZipArchive()
        
        let temp = NSString(string: path).deletingPathExtension //去掉文件扩展名
        let fileName = NSString(string: temp).lastPathComponent //获取文件名
        
        if zip.unzipOpenFile(path) {
            
            let documentPath = FileManager.default.documentPath
            let zipPath = "\(documentPath)/\(fileName)" //解压后的目录
            
            let fileManager = FileManager.default
            
            if fileManager.fileExists(atPath: zipPath) {
                //存在上次的内容则删除
                try? fileManager.removeItem(atPath: zipPath)
            }
            
            //解压文件
            if zip.unzipFile(to: zipPath + "/", overWrite: true) {
                return fileName //相对路径
            }
        }
        
        return nil;
        
    }
    
    /*
    //MARK: - OPF文件路径
    private static func OPFPath(epubPath:String?) -> String? {
        guard let epubPath_ = epubPath else { return nil }
        let containerPath = "\(FileManager.default.documentPath)/\(epubPath_)/META-INF/container.xml"
        //container.xml文件路径 通过container.xml获取到opf文件的路径
        let fileManager = FileManager.default
        if fileManager.fileExists(atPath: containerPath) {
            let documentUrl = URL(fileURLWithPath: containerPath)
            let document = try! CXMLDocument(contentsOf: documentUrl, options: 0)
            let opfPath = try! document.nodes(forXPath:"//@full-path").last as! CXMLNode
            // xml文件中获取full-path属性的节点  full-path的属性值就是opf文件的绝对路径
            let path = "\(epubPath_)/\(opfPath.stringValue()!)"
            return path
        } else {
            print("ERROR: ePub not Valid")
            return nil
        }
    }
    
    //MARK: - 解析OPF文件
    private static func parseOPF(bookID:String,opfPath:String?) -> [DZMReadChapterListModel] {
        
        var chapterList = [DZMReadChapterListModel]()

        guard let opfPath_ = opfPath else { return chapterList }
        let documentUrl = URL(fileURLWithPath: "\(FileManager.default.documentPath)/\(opfPath_)")
        let document = try! CXMLDocument(contentsOf: documentUrl, options: 0)
        
        let itemsArray = try! document.nodes(forXPath: "//opf:item", namespaceMappings: ["opf":"http://www.idpf.org/2007/opf"]) as! [CXMLElement]
        //opf文件的命名空间 xmlns="http://www.idpf.org/2007/opf" 需要取到某个节点设置命名空间的键为opf 用opf:节点来获取节点
        var ncxFile = ""
        var itemDictionary = [String:String]()
        for element in itemsArray {
            let href = element.attribute(forName: "href").stringValue()!
            let id = element.attribute(forName: "id").stringValue()!
            itemDictionary[id] = href
            
            if let mediaType = element.attribute(forName: "media-type").stringValue(),mediaType == "application/x-dtbncx+xml",let ncxHref = element.attribute(forName: "href").stringValue() {
                ncxFile = ncxHref //获取ncx文件名称 根据ncx获取书的目录
            }
        }
        
        //ncxfile
        let absolutePath = NSString(string: "\(FileManager.default.documentPath)/\(opfPath_)").deletingLastPathComponent
        let ncxDocumentUrl = URL(fileURLWithPath: "\(absolutePath)/\(ncxFile)")
        let ncxDoc = try! CXMLDocument(contentsOf: ncxDocumentUrl, options: 0)
        var titleDictionary = [String:String]()
        
        for element in itemsArray {
            let href = element.attribute(forName: "href").stringValue()!
            var xpath = "//ncx:content[@src='\(href)']/../ncx:navLabel/ncx:text"
            
            //根据opf文件的href获取到ncx文件中的中对应的目录名称
            var navPoints = try! ncxDoc.nodes(forXPath: xpath, namespaceMappings: ["ncx":"http://www.daisy.org/z3986/2005/ncx/"]) as! [CXMLElement]
            
            if navPoints.count == 0 {
                let contentpath = "//ncx:content"
                let contents = try! ncxDoc.nodes(forXPath: contentpath, namespaceMappings: ["ncx":"http://www.daisy.org/z3986/2005/ncx/"]) as! [CXMLElement]
                for ele in contents {
                    let src = ele.attribute(forName: "src").stringValue()!
                    if src.hasPrefix(href) {
                        xpath = "//ncx:content[@src='\(src)']/../ncx:navLabel/ncx:text"
                        navPoints = try! ncxDoc.nodes(forXPath: xpath, namespaceMappings: ["ncx":"http://www.daisy.org/z3986/2005/ncx/"]) as! [CXMLElement]
                        break
                    }
                }
            } else {
                let titleElement = navPoints.first!
                titleDictionary[href] = titleElement.stringValue()!
            }
        }
        
        let itemRefsArray = try! document.nodes(forXPath: "//opf:itemref", namespaceMappings: ["opf":"http://www.idpf.org/2007/opf"]) as! [CXMLElement]
        
        
        for index in 0 ..< itemRefsArray.count {
            
            let element = itemRefsArray[index]
            let idref = element.attribute(forName: "idref").stringValue()!
            let chapHref = itemDictionary[idref]!
            
            let chapterContentUrl = "\(absolutePath)/\(chapHref)"
            let title = titleDictionary[chapHref]!
            //let imagePath =  NSString(string: NSString(string: NSString(string: opfPath_).deletingLastPathComponent ).appendingPathComponent(chapHref) ).deletingLastPathComponent
            
            
            // 创建章节内容模型
            let readChapterModel = DZMReadChapterModel()
            
            // 书ID
            readChapterModel.bookID = bookID
            
            // 章节ID
            readChapterModel.id = "\(index)"
            
            // 优先级
            readChapterModel.priority = NSNumber(value: index)
            
            // 章节名
            readChapterModel.name = title
            
            //图片文件夹
            let imagedir = NSString(string: opfPath_).deletingLastPathComponent
            readChapterModel.imageDirectory = imagedir
            
            //MARK - 内容
            let contentData = try! Data(contentsOf: URL(fileURLWithPath: chapterContentUrl))
            let contentHTML = String(data: contentData, encoding: .utf8)!
            readChapterModel.content = contentHTML
            
            // 分页
            readChapterModel.updateFont()
            
            // 添加章节列表模型
            chapterList.append(GetReadChapterListModel(readChapterModel: readChapterModel))
            
            // 保存
            readChapterModel.save()
        }
        
        return chapterList
    }
    */
    
    //MARK: - 解析txt文件
    /**
     主线程 解析本地URL
     
     - parameter url: URL
     
     - returns: ReadModel
     */
    class func ParserLocalURL(url:URL) ->DZMReadModel {
        
        let bookID = GetFileName(url)
        
        if !DZMReadModel.IsExistReadModel(bookID: bookID) { // 不存在
           
            // 阅读模型
            let readModel = DZMReadModel.readModel(bookID: bookID)
            
            // 解析数据
            let content = DZMReadParser.EncodeURL(url)
            
            // 获得章节列表
            readModel.readChapterListModels = ParserContent(bookID: bookID, content: content)
            
            // 设置阅读记录 第一个章节 为 "1"
            readModel.modifyReadRecordModel(chapterID: "1")
            
            // 保存
            readModel.save()
            
            // 返回
            return readModel
            
        }else{ // 存在
            
            // 返回
            return DZMReadModel.readModel(bookID: bookID)
        }
    }
    
    // MARK: -- 解析Context
    
    /**
     解析Context
     
     - parameter bookID: 小说ID
     
     - parameter content: 内容
     
     - returns: 章节列表模型数组
     */
    private class func ParserContent(bookID:String, content:String) ->[DZMReadChapterListModel] {
        
        // 章节列表数组
        var readChapterListModels:[DZMReadChapterListModel] = []
        
        // 正则
        let parten = "第[0-9一二三四五六七八九十百千]*[章回].*"
        
        // 搜索
        var results:[NSTextCheckingResult] = []
        
        do{
            let regularExpression:NSRegularExpression = try NSRegularExpression(pattern: parten, options: NSRegularExpression.Options.caseInsensitive)
            
            results = regularExpression.matches(in: content, options: NSRegularExpression.MatchingOptions.reportProgress, range: NSRange(location: 0, length: content.length))
            
        }catch{
            
            return readChapterListModels
        }
        
        // 解析搜索结果
        if !results.isEmpty {
           
            // 记录最后一个Range
            var lastRange = NSMakeRange(0, 0)
            
            // 数量
            let count = results.count
            
            // 便利
            for i in 0..<count {
                
                // 打印解析进度
                print("总章节数:\(count)  当前解析到:\(i + 1)")
                
                // range
                let range = results[i].range
                
                let location = range.location
                
                // 创建章节内容模型
                let readChapterModel = DZMReadChapterModel()
                
                // 书ID
                readChapterModel.bookID = bookID
                
                // 章节ID
                readChapterModel.id = "\(i + 1)"
                
                // 优先级
                readChapterModel.priority = NSNumber(value: i)
                
                if i == 0 { // 开始
                    
                    // 章节名
                    readChapterModel.name = "开始"
                    
                    // 内容
                    readChapterModel.content = ContentTypesetting(content: content.substring(NSMakeRange(0, location)))
                    
                    // 记录
                    lastRange = range
                    
                    // 说不定没有内容 则不需要添加到列表
                    if readChapterModel.content.isEmpty {continue}
                    
                }else if i == count { // 结尾
                    
                    // 章节名
                    readChapterModel.name = content.substring(lastRange)
                    
                    // 内容
                    readChapterModel.content = ContentTypesetting(content: content.substring(NSMakeRange(lastRange.location, content.length - location)))
        
                }else { // 中间章节
                    
                    // 章节名
                    readChapterModel.name = content.substring(lastRange)
                    
                    // 内容
                    readChapterModel.content = ContentTypesetting(content: content.substring(NSMakeRange(lastRange.location, location - lastRange.location)))
                }
                
                // 分页
                readChapterModel.updateFont()
                
                // 添加章节列表模型
                readChapterListModels.append(GetReadChapterListModel(readChapterModel: readChapterModel))
                
                // 保存
                readChapterModel.save()
                
                // 记录
                lastRange = range
            }
            
        }else{
            
            // 创建章节内容模型
            let readChapterModel = DZMReadChapterModel()
            
            // 书ID
            readChapterModel.bookID = bookID
            
            // 章节ID
            readChapterModel.id = "1"
            
            // 章节名
            readChapterModel.name = "开始"
            
            // 优先级
            readChapterModel.priority = NSNumber(value: 0)
            
            // 内容
            readChapterModel.content = ContentTypesetting(content: content)
            
            // 分页
            readChapterModel.updateFont()
            
            // 添加章节列表模型
            readChapterListModels.append(GetReadChapterListModel(readChapterModel: readChapterModel))
            
            // 保存
            readChapterModel.save()
        }
        
        return readChapterListModels
    }
    
    /**
     通过阅读章节内容模型 获得 阅读章节列表模型
     
     - parameter readChapterModel: 阅读章节内容模型
     
     - returns: 阅读章节列表模型
     */
    private class func GetReadChapterListModel(readChapterModel:DZMReadChapterModel) ->DZMReadChapterListModel {
        
        let readChapterListModel = DZMReadChapterListModel()
        
        readChapterListModel.bookID = readChapterModel.bookID
        
        readChapterListModel.id = readChapterModel.id
        
        readChapterListModel.name = readChapterModel.name
        
        readChapterListModel.priority = readChapterModel.priority
        
        return readChapterListModel
    }
        
    // MARK: -- 对内容进行整理排版 比如去掉多余的空格或者段头留2格等等
    
    /// 内容排版整理
    class func ContentTypesetting(content:String) ->String {

        // 替换单换行
        var content = content.replacingOccurrences(of: "\r", with: "")
        
        // 替换换行 以及 多个换行 为 换行加空格
        content = content.replacingCharacters(pattern: "\\s*\\n+\\s*", template: "\n　　")
        
        // 返回
        return content
    }
    
    
    // MARK: -- 解码URL
    
    /// 解码URL
    class func EncodeURL(_ url:URL) ->String {
        
        var content = ""
        
        // 检查URL是否有值
        if url.absoluteString.isEmpty {
            
            return content
        }
        
        // NSUTF8StringEncoding 解析
        content = EncodeURL(url, encoding: String.Encoding.utf8.rawValue)
        
        // 进制编码解析
        if content.isEmpty {
            
            content = EncodeURL(url, encoding: 0x80000632)
        }
        
        if content.isEmpty {
            
            content = EncodeURL(url, encoding: 0x80000631)
        }
        
        if content.isEmpty {
            
            content = ""
        }
        
        return content
    }
    
    /// 解析URL
    private class func EncodeURL(_ url:URL,encoding:UInt) ->String {
        
        do{
            return try NSString(contentsOf: url, encoding: encoding) as String
            
        }catch{}
        
        return ""
    }
    
}
