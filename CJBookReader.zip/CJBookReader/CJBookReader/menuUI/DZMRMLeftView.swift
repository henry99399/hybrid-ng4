//
//  DZMRMLeftView.swift
//  DZMeBookRead
//
//  Created by 邓泽淼 on 2017/5/15.
//  Copyright © 2017年 DZM. All rights reserved.
//

import UIKit

class DZMRMLeftView: DZMRMBaseView,DZMSegmentedControlDelegate,UITableViewDelegate,UITableViewDataSource {
    
    /// topView
    private(set) var topView:DZMSegmentedControl!
    
    /// UITableView
    lazy var chapterTableView = UITableView(frame: CGRect.zero, style: .plain)
    lazy var markTableView = UITableView(frame: CGRect.zero, style: .plain)

    /// contentView
    private(set) var contentView:UIView!
    
    /// 类型 0: 章节 1: 书签
    private var type:NSInteger = 0
    
    override func addSubviews() {
        
        super.addSubviews()
        
        // contentView
        self.contentView = UIView()
        self.contentView.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        addSubview(self.contentView)
        
        // UITableView
        self.chapterTableView.register(CJMenuChapterCell.self, forCellReuseIdentifier: "CJMenuChapterCell")
        self.chapterTableView.register(CJMenuMarkCell.self, forCellReuseIdentifier: "CJMenuMarkCell")
        self.chapterTableView.backgroundColor = UIColor.clear
        self.chapterTableView.separatorStyle = .none
        self.chapterTableView.contentInset = UIEdgeInsets(top: 20.0, left: 0, bottom: 0, right: 0)
        self.chapterTableView.delegate = self
        self.chapterTableView.dataSource = self
        self.contentView.addSubview(self.chapterTableView)
        
        self.markTableView.register(CJMenuMarkCell.self, forCellReuseIdentifier: "CJMenuMarkCell")
        self.markTableView.register(CJMenuChapterCell.self, forCellReuseIdentifier: "CJMenuChapterCell")
        self.markTableView.contentInset = UIEdgeInsets(top: 20.0, left: 0, bottom: 0, right: 0)
        self.markTableView.backgroundColor = UIColor.clear
        self.markTableView.separatorStyle = .none
        self.markTableView.delegate = self
        self.markTableView.dataSource = self
        self.contentView.addSubview(self.markTableView)
        
        // topView
        self.topView = DZMSegmentedControl()
        self.topView.delegate = self
        self.topView.normalTitles = ["章节","书签"]
        self.topView.selectTitles = ["章节","书签"]
        self.topView.horizontalShowTB = false
        self.topView.backgroundColor = UIColor.clear
        self.topView.normalTitleColor = DZMColor_6
        self.topView.selectTitleColor = DZMColor_2
        self.topView.setup()
        self.contentView.addSubview(self.topView)
        
        self.contentView.snp.makeConstraints { (make) in
            make.right.equalTo(self.snp.left)
            make.top.equalToSuperview()
            make.width.equalTo(self.snp.width).multipliedBy(0.8)
            make.height.equalToSuperview()
        }
        
        self.topView.snp.makeConstraints { (make) in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(45.0)
        }
        
        self.chapterTableView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.top.equalTo(self.topView.snp.bottom)
        }
        
        self.markTableView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.top.equalTo(self.topView.snp.bottom)
        }
        self.markTableView.isHidden = true
        
    }
    
    // MARK: -- DZMSegmentedControlDelegate
    func segmentedControl(segmentedControl: DZMSegmentedControl, clickButton button: UIButton, index: NSInteger) {
        
        type = index
        
        if type == 0 {
            self.chapterTableView.reloadData()
            self.chapterTableView.isHidden = false
            self.markTableView.isHidden = true
        } else {
            self.markTableView.reloadData()
            self.chapterTableView.isHidden = true
            self.markTableView.isHidden = false
        }
    }
    
    // MARK: -- UITableViewDelegate,UITableViewDataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if type == 0 { // 章节
            if readMenu.vc.cjReadModel.bookType == .txt {
                return (readMenu.vc.cjReadModel.txtChapterList.count)
            } else {
                return (readMenu.vc.cjReadModel.epubChapterList.count)
            }
        }else{ // 书签
            return readMenu.vc.cjReadModel.marks.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if type == 0 { //章节
            let cell = tableView.dequeueReusableCell(withIdentifier: "CJMenuChapterCell") as! CJMenuChapterCell
            let book = readMenu.vc.cjReadModel
            cell.refresh(book: book, chapterIndex: indexPath.row)
            return cell
        } else { //书签
            let cell = tableView.dequeueReusableCell(withIdentifier: "CJMenuMarkCell") as! CJMenuMarkCell
            
            if indexPath.row < readMenu.vc.cjReadModel.marks.count {
                let markModel = readMenu.vc.cjReadModel.marks[indexPath.row]
                cell.refresh(mark: markModel)
            }

            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if type == 0 { // 章节
            return 40.0
        } else { // 书签
            return 80.0
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        if type == 0 { // 章节
            if readMenu.vc.cjReadModel.bookType == .txt {
                readMenu.delegate?.readMenuClickTxtChapterList?(readMenu: readMenu, readChapterListModel: readMenu.vc.cjReadModel.txtChapterList[indexPath.row])
            } else {
                readMenu.delegate?.readMenuClickEpubChapterList?(readMenu: readMenu, readChapterListModel: readMenu.vc.cjReadModel.epubChapterList[indexPath.row])
            }
        } else { // 书签
            readMenu.delegate?.readMenuClickMarkList?(readMenu: readMenu, readMarkModel: readMenu.vc.cjReadModel.marks[indexPath.row])
        }
        
        // 隐藏
        readMenu.leftView(isShow: false, complete: nil)
    }
    
    // MARK: -- 删除操作
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        
        if type == 0 { // 章节
            return false
        }else{ // 书签
            return true
        }
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        self.readMenu.vc.cjReadModel.deleteReadmark(readMark: nil, index: indexPath.row,callback: { [weak self] in
            self?.markTableView.reloadData()
        })
        //tableView.deleteRows(at: [indexPath], with: UITableViewRowAnimation.fade)
    }
}

class CJMenuChapterCell : UITableViewCell {
    
    private lazy var labelName = UILabel()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.backgroundColor = UIColor.clear
        self.contentView.addSubview(self.labelName)
        self.labelName.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15.0)
            make.right.equalToSuperview().offset(-15.0)
            make.centerY.equalToSuperview()
        }
        
        let line = UIView()
        line.backgroundColor = UIColor(red: 0x40 / 255.0, green: 0x40 / 255.0, blue: 0x40 / 255.0, alpha: 1)
        self.contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.height.equalTo(0.5)
            make.left.equalToSuperview().offset(15.0)
            make.right.equalToSuperview().offset(-15.0)
            make.bottom.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func refresh(book:CJBook,chapterIndex:Int) {
        if book.bookType == .txt {
            
            if chapterIndex >= book.txtChapterList.count {return} //防止闪退
            
            let chapter = book.txtChapterList[chapterIndex]
            
            self.labelName.text = chapter.ch_name
            if chapter.is_buyed {
                self.labelName.textColor = DZMColor_6
            } else {
                self.labelName.textColor = DZMColor_7
            }
            
            if let recordId = book.record.txtChapter?.ch_id,recordId == chapter.ch_id {
                self.labelName.textColor = DZMColor_2
            }
        }
        else {
            if chapterIndex >= book.epubChapterList.count {return} //防止闪退
            
            let chapter = book.epubChapterList[chapterIndex]
            
            self.labelName.text = chapter.name
            if chapter.is_free {
                self.labelName.textColor = DZMColor_6
            } else {
                self.labelName.textColor = DZMColor_7
            }
            
            if let recordId = book.record.epubChapter?.id,recordId == chapter.id {
                self.labelName.textColor = DZMColor_2
            }
            
        }
        
        self.labelName.font = DZMFont_14
    }
}

class CJMenuMarkCell : UITableViewCell {
    
    private lazy var labelName = UILabel()
    private lazy var labelTime = UILabel()
    private lazy var labelContent = UILabel()

    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.backgroundColor = UIColor.clear
        
        self.contentView.addSubview(self.labelName)
        self.labelName.font = DZMFont_12
        self.labelName.textColor = DZMColor_6
        self.labelName.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15.0)
            make.right.equalToSuperview().offset(-75.0)
            make.top.equalToSuperview().offset(10.0)
        }
        
        self.contentView.addSubview(self.labelTime)
        self.labelTime.font = DZMFont_12
        self.labelTime.textColor = DZMColor_6
        self.labelTime.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-15.0)
            make.top.equalToSuperview().offset(10.0)
        }
        
        self.contentView.addSubview(self.labelContent)
        self.labelContent.font = DZMFont_12
        self.labelContent.textColor = DZMColor_6
        self.labelContent.numberOfLines = 0
        self.labelContent.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(20.0)
            make.right.equalToSuperview().offset(-15.0)
            make.top.equalTo(self.labelName.snp.bottom).offset(10.0)
            make.bottom.equalToSuperview().offset(-10.0)
        }
        
        let line = UIView()
        line.backgroundColor = UIColor(red: 0x40 / 255.0, green: 0x40 / 255.0, blue: 0x40 / 255.0, alpha: 1)
        self.contentView.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.height.equalTo(0.5)
            make.left.equalToSuperview().offset(15.0)
            make.right.equalToSuperview().offset(-15.0)
            make.bottom.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func refresh(mark:CJMark) {
        let name = mark.name
        let time =  mark.create_time.desString() //GetTimerString(dateFormat: "YYYY-MM-dd HH:mm:ss", date: Date(timeIntervalSince1970: mark.create_time))
        let content = mark.content
        self.labelName.text = name
        self.labelTime.text = time
        self.labelContent.text = content
    }
}
