//
//  String+CJ.swift
//  AHQBookRead
//
//  Created by lidi on 2017/10/28.
//  Copyright © 2017年 ahq. All rights reserved.
//

import Foundation
extension String {
    
    func filterTxt() -> String {
        var filted = self.replacingOccurrences(of: "&nbsp;", with: " ")
        filted = filted.replacingOccurrences(of: "<br>", with: "\n")
        
        // 替换单换行
        filted = filted.replacingOccurrences(of: "\r", with: "")
        
        // 替换换行 以及 多个换行 为 换行加空格
        filted = filted.replacingCharacters(pattern: "\\s*\\n+\\s*", template: "\n  ")
        
        return filted
    }
    
}
