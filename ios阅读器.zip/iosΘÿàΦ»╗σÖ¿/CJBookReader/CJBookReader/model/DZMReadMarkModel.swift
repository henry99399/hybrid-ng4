//
//  DZMReadMarkModel.swift
//  DZMeBookRead
//
//  Created by 邓泽淼 on 2017/5/12.
//  Copyright © 2017年 DZM. All rights reserved.
//

import UIKit

class DZMReadMarkModel: NSObject,NSCoding {
    
    /// 时间
    var time:Date!
    
    //阅读记录
    var recordModel:DZMReadRecordModel?
    
    // MARK: -- init
    override init() {
        super.init()
    }
    
    // MARK: -- NSCoding
    required init?(coder aDecoder: NSCoder) {
        
        super.init()
        self.recordModel = aDecoder.decodeObject(forKey: "recordModel") as? DZMReadRecordModel
        self.time = aDecoder.decodeObject(forKey: "time") as! Date
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(self.recordModel, forKey: "recordModel")
        aCoder.encode(self.time, forKey: "time")
    }
}
