//
//  DZMReadChapterModel.swift
//  DZMeBookRead
//
//  Created by 邓泽淼 on 2017/5/12.
//  Copyright © 2017年 DZM. All rights reserved.
//

import UIKit

class DZMReadChapterModel: NSObject,NSCoding {
    
    /// 小说ID
    var bookID = ""
    
    /// 章节ID
    var id = ""
    
    /// 章节名称
    var name = ""
    
    /// 优先级 (一般章节段落都带有排序的优先级 从 0 开始)
    var priority:NSNumber!
    
    //图片文件夹相对路径
    var imageDirectory = ""
    
    /// 内容
    var content = "" {
        didSet {
            self.parthHTMLContent()
        }
    }
    
    /// 本章有多少页
    var pageCount:Int {
        return self.chapterFrames.count
    }
    
    // MARK: -- 更新字体
    
    /// 记录该章使用的字体属性
    private var readAttribute:[String:NSObject] = [:]
    
    /// 更新字体
    func updateFont(isSave:Bool = false) {
        
        let readAttribute = DZMReadConfigure.shared().readAttribute()
        
        
        if self.readAttribute != readAttribute {
            
            self.readAttribute = readAttribute
            
            //rangeArray = self.parserPageRange(string: content, rect: GetReadViewFrame(), attrs: readAttribute)
            
            //新版分页
            self.paginate(bounds: GetReadViewFrame())
            
            if isSave {save()}
        }
    }
    
    // MARK: -- init
    override init() {
        super.init()
    }
    
    /// 通过书ID 章节ID 获得阅读章节 没有则创建传出
    class func readChapterModel(bookID:String, chapterID:String, isUpdateFont:Bool = false) ->DZMReadChapterModel {
        
        var readChapterModel:DZMReadChapterModel!
        
        if DZMReadChapterModel.IsExistReadChapterModel(bookID: bookID, chapterID: chapterID) { // 存在
            
            readChapterModel = ReadKeyedUnarchiver(folderName: bookID, fileName: chapterID) as! DZMReadChapterModel
            
            if isUpdateFont {readChapterModel.updateFont(isSave: true)}
            
        }else{ // 不存在
            
            readChapterModel = DZMReadChapterModel()
            
            readChapterModel.bookID = bookID
            
            readChapterModel.id = chapterID
        }
        
        return readChapterModel
    }
    
    // MARK: -- 操作

    /// 保存
    func save() {
        
        ReadKeyedArchiver(folderName: bookID, fileName: id, object: self)
    }
    
    /// 是否存在章节内容模型
    class func IsExistReadChapterModel(bookID:String, chapterID:String) ->Bool {
        
        return ReadKeyedIsExistArchiver(folderName: bookID, fileName: chapterID)
    }
    
    // MARK: -- 内容分页
    
    /**
     内容分页
     
     - parameter string: 内容
     
     - parameter rect: 范围
     
     - parameter attrs: 文字属性
     
     - returns: 每一页的起始位置数组
     */
    private func parserPageRange(string:String, rect:CGRect, attrs:[String : Any]?) ->[NSRange] {
        
        // 记录
        var rangeArray = [NSRange]()
        
        // 拼接字符串
        let attrString = NSMutableAttributedString(string: string, attributes: attrs)
        
        let frameSetter = CTFramesetterCreateWithAttributedString(attrString as CFAttributedString)
        
        let path = CGPath(rect: rect, transform: nil)
        
        var range = CFRangeMake(0, 0)
        
        var rangeOffset:NSInteger = 0
        
        repeat{
            
            let frame = CTFramesetterCreateFrame(frameSetter, CFRangeMake(rangeOffset, 0), path, nil)
            
            range = CTFrameGetVisibleStringRange(frame)
            
            rangeArray.append(NSMakeRange(rangeOffset, range.length))
            
            rangeOffset += range.length
            
        }while(range.location + range.length < attrString.length)
        
        
        return rangeArray
    }
    
    // MARK: -- NSCoding
    
    required init?(coder aDecoder: NSCoder) {
        
        super.init()
        
        bookID = aDecoder.decodeObject(forKey: "bookID") as! String
        
        id = aDecoder.decodeObject(forKey: "id") as! String
        
        name = aDecoder.decodeObject(forKey: "name") as! String
        
        priority = aDecoder.decodeObject(forKey: "priority") as! NSNumber
        
        imageDirectory = aDecoder.decodeObject(forKey: "imageDirectory") as! String
        
        self.content = aDecoder.decodeObject(forKey: "content") as! String
        self.parthHTMLContent()

        readAttribute = aDecoder.decodeObject(forKey: "readAttribute") as! [String:NSObject]
    }
    
    func encode(with aCoder: NSCoder) {
        
        aCoder.encode(bookID, forKey: "bookID")
        
        aCoder.encode(id, forKey: "id")
        
        aCoder.encode(name, forKey: "name")
        
        aCoder.encode(priority, forKey: "priority")
        
        aCoder.encode(imageDirectory, forKey: "imageDirectory")
        
        aCoder.encode(content, forKey: "content")
        
        aCoder.encode(readAttribute, forKey: "readAttribute")
    }
    
    //MARK: - epub
    
    private var epubContents = [DZMReadContentInfo]() //章节内容，多种类型，最终拼接成章节内容
    private var images = [DZMReadImageInfo]() //章节对应的插图
    
    var chapterFrames = [Any]()
    
    //填充html
    private func parthHTMLContent() {
        let content = NSString(string: self.content).convertingHTMLToPlainText()!
        
        //解析
        var contents = [DZMReadContentInfo]()
        var images = [DZMReadImageInfo]()
        
        let scanner = Scanner(string: content)
        var targetContent = ""
        
        while !scanner.isAtEnd {
            if scanner.scanString("<img>", into: nil) {
                
                var temp:NSString? = ""
                scanner.scanUpTo("</img>", into: &temp)
                
                let contentInfo = DZMReadContentInfo()
                contentInfo.type = .img
                
                let imagePath = self.imageDirectory + "/" + (temp! as String) as String
                if let imageSize = UIImage(contentsOfFile:"\(FileManager.default.documentPath)/\(imagePath)")?.size {
                    
                    let readViewSize = GetReadViewFrame().size
                    
                    var width = imageSize.width
                    var height = imageSize.height
                    
                    if width > readViewSize.width {
                        height = height * (readViewSize.width / width)
                        width = readViewSize.width
                    }
                    
                    if height > readViewSize.height {
                        width = width * (readViewSize.height / height)
                        height = readViewSize.height
                    }
                    
                    contentInfo.width = width
                    contentInfo.height = height
                }
                
                contentInfo.content = imagePath

                contents.append(contentInfo)
                
                //存储图片信息
                let imageInfo = DZMReadImageInfo()
                imageInfo.url = String(temp!)
                imageInfo.position = targetContent.length
                images.append(imageInfo)
                
                scanner.scanString("</img>", into: nil)
            } else {
                var temp:NSString? = ""
                if scanner.scanUpTo("<img>", into: &temp) {
                    var con = ""
                    if let temp_ = temp {
                        con = String(temp_)
                    }

                    let contentInfo = DZMReadContentInfo()
                    contentInfo.type = .txt
                    contentInfo.content = String(temp!)
                    contents.append(contentInfo)
                    
                    targetContent += con
                }
            }
        }
        
        self.epubContents = contents
        self.images = images
    }
    
    //分页
    private func paginate(bounds:CGRect) {
        
        let attrString = NSMutableAttributedString()
        for content in self.epubContents {
            switch content.type {
            case .txt:
                //解析文本
                let attr = self.readAttribute
                let subString = NSMutableAttributedString(string: content.content, attributes: attr)
                attrString.append(subString)
            case .img:
                
                //解析图片
                var imageCallback = CTRunDelegateCallbacks(version: kCTRunDelegateVersion1, dealloc: { (refCon) in
                    
                }, getAscent: {(refCon) -> CGFloat in
                    //高度
                    let opaquePtr = OpaquePointer(refCon)
                    let contextPtr = UnsafeMutablePointer<DZMReadContentInfo>(opaquePtr)
                    let contentInfo = contextPtr.pointee
                    let height = contentInfo.height
                    return height
                }, getDescent: { (refCon) -> CGFloat in
                    return 0  //返回底部距离
                }, getWidth: { (refCon) -> CGFloat in
                    //宽度
                    let opaquePtr = OpaquePointer(refCon)
                    let contextPtr = UnsafeMutablePointer<DZMReadContentInfo>(opaquePtr)
                    let contentInfo = contextPtr.pointee
                    let width = contentInfo.width
                    return width
                })
                
                var contentInfo = content
                
                let runDelegate = CTRunDelegateCreate(&imageCallback, &contentInfo)!
                let subString = NSMutableAttributedString(string: "\n")  // 空格用于给图片留位置
                subString.addAttribute(kCTRunDelegateAttributeName as String, value: runDelegate, range: NSMakeRange(0, 1))  //rundelegate  占一个位置
                subString.addAttribute("imagePath", value: contentInfo.content, range: NSMakeRange(0, 1))//添加属性，在CTRun中可以识别出这个字符是图片
                attrString.append(subString)
            }
        }
        
        let setterRef = CTFramesetterCreateWithAttributedString(attrString)
        let pathRef = CGPath(rect: bounds, transform: nil)
        
        let frameRef = CTFramesetterCreateFrame(setterRef, CFRange(location: 0, length: 0), pathRef, nil)
        
        
        var rang1 = CTFrameGetVisibleStringRange(frameRef)
        let rang2 = CTFrameGetStringRange(frameRef)
        
        var frames = [CTFrame]()
        
        if rang1.length + rang1.location == rang2.length + rang2.location {
            
            let subFrameRef = CTFramesetterCreateFrame(setterRef,CFRange(location: rang1.location, length: 0), pathRef, nil)
            let range = CTFrameGetVisibleStringRange(subFrameRef)
            rang1 = CFRange(location: range.location + range.length,length: 0)
            frames.append(subFrameRef)
        } else {
            
            while rang1.length + rang1.location < rang2.location + rang2.length {
                let subFrameRef = CTFramesetterCreateFrame(setterRef,CFRange(location: rang1.location, length: 0), pathRef, nil)
                let range = CTFrameGetVisibleStringRange(subFrameRef)
                rang1 = CFRange(location: range.location + range.length,length: 0)
                frames.append(subFrameRef)
            }
        }
        
        self.chapterFrames = frames
    }
    
}

class DZMReadContentInfo:NSObject {
    enum InfoType {
        case txt
        case img
    }
    
    var type = InfoType.txt
    var content = ""
    
    var width:CGFloat = 0
    var height:CGFloat = 0
}

class DZMReadImageInfo:NSObject {
    var url = "" //图片链接
    var imageRect = CGRect.zero //图片位置
    var position = 0
}
