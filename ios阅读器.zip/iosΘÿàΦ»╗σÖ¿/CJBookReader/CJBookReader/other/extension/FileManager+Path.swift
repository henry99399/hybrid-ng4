//
//  FileManager+Path.swift
//  AHQBookRead
//
//  Created by lidi on 2017/9/14.
//  Copyright © 2017年 ahq. All rights reserved.
//

import Foundation

extension FileManager {
    
    var documentPath:String {
        if let documentPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first {
            return documentPath
        } else {
            return ""
        }
    }
    
    //用户对应的图书缓存
    func cachePathFor(userId:String) -> String {
        let cachePath = NSSearchPathForDirectoriesInDomains(.cachesDirectory, .userDomainMask, true).last!
        let userCachePath = cachePath + "/" + "bookcache_\(userId)"
        if !self.fileExists(atPath: userCachePath, isDirectory: nil) {
            try? FileManager.default.createDirectory(atPath: userCachePath, withIntermediateDirectories: true, attributes: nil)
        }
        return userCachePath
    }

}
