//
//  TimeInterval+String.swift
//  CJBookReader
//
//  Created by lidi on 2017/11/2.
//  Copyright © 2017年 lidi. All rights reserved.
//

import Foundation

extension TimeInterval {
    
    func desString() -> String {
        let now = NSDate().timeIntervalSince1970
        var sec = now - self
        
        if (sec < 60) {
            return "刚刚"
        }
        
        sec = sec / 60
        if sec < 60 {
            return "\(Int(sec))分钟前"
        }

        sec = sec / 60
        if sec < 24 {
            return "\(Int(sec))小时前"
        }
        
        sec = sec / 24
        if sec < 30 {
            return "\(Int(sec))天前"
        }
            
        sec = sec / 30
        if sec < 12 {
            return "\(Int(sec))月前"
        }
        
        sec = sec / 12
        return "\(Int(sec))年前"
        
    }
    
}
