//
//  NSString+md5.h
//  BookReader
//
//  Created by lidi on 2017/10/31.
//  Copyright © 2017年 lidi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (md5)

- (nonnull NSString *)toMD5;

@end
