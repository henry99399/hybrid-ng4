//
//  CJUserInfo.swift
//  AHQBookRead
//
//  Created by lidi on 2017/10/29.
//  Copyright © 2017年 ahq. All rights reserved.
//

import UIKit

public class CJUserInfo: NSObject {

    public static let shared = CJUserInfo()
    
    public var token = ""
    public var userId = ""
    public var baseUrl = "http://cjszyun.net"
}
