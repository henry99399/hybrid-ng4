//
//  Router.swift
//  yilule
//
//  Created by colin on 2017/6/21.
//  Copyright © 2017年 Colin. All rights reserved.
//

import Foundation

typealias JSONObject = [String:Any]

enum Router {
    
    //网文部分
    case _fetchBookChapters(book_id:String) //获取网文章节列表接口
    case _fetchBookChapterContent(book_id:String,ch_id:String) //获取网文章节内容
    
    //图书部分
    case _fetchHTMLBookChapters(book_id:String) //获取图书章节Tree
    case _fetchHTMLBookChapterContent(book_id:String,chapter_id:String) //图书阅读，获取章节内容
    
    //书签部分
    case _addBookMark(chapter_id:String,content:String,book_type:String,chapter_name:String,book_id:String) //添加书签
    case _fetchBookMarks(book_id:String) //获取书签列表
    case _deleteBookMark(marks:String) //删除书签 marks 书签ID（多选，逗号分隔）
    
    //图书购买部分
    case _buyEpub(book_id:String) //购买epub
    case _buyTxt(book_id:String,ch_id:String,count:Int) //购买网文章节
    case _fetchTxtPrice(book_id:String,ch_id:String,count:Int) //获取网文章节价格
    case _fetchEpubPrice(book_id:String) //获取epub图书价格
    
    //用户相关的部分
    case _saveUserRecord(book_id:String,last_chapter_id:String,
        schedule:String,book_type:String,book_name:String,book_cover:String,chapter_name:String)  //移动端用户阅读记录接口
}

extension Router {
    var path:String {
        switch self {
        case ._fetchBookChapters:
            return "/v3/bookChapter/list"
        case ._fetchBookChapterContent:
            return "/v3/chapter/content"
        case ._fetchHTMLBookChapters:
            return "/v3/api/book/chapterTree"
        case ._fetchHTMLBookChapterContent:
            return "/v3/api/book/getChapterContent"
        case ._addBookMark:
            return "/v2/api/member/addBookMark"
        case ._fetchBookMarks:
            return "/v2/api/member/getMarkList"
        case ._deleteBookMark:
            return "/v2/api/member/deleteMarks"
        case ._buyEpub:
            return "/v3/bookOrder/saveOrder"
        case ._buyTxt:
            return "/v3/payChapter/buyChapter"
        case ._fetchTxtPrice:
            return "/v3/payChapter/getPrice"
        case ._fetchEpubPrice:
            return "/v3/payBook/getPrice"
        case ._saveUserRecord:
            return "/v3/api/bookShelf/updateMemberReadRecord"
        }
    }
}

extension Router {
    var parameters:JSONObject {
        
        var params = JSONObject()
        
        /****必传参数*****/
        params["token_type"] = "ios" //token类型(pc/ios/android/weixin/max）
        params["member_token"] = CJUserInfo.shared.token  //用户ID
        
        switch self {
        case let ._fetchBookChapters(book_id):
            params["book_id"] = book_id
        case let ._fetchBookChapterContent(book_id, ch_id):
            params["book_id"] = book_id
            params["ch_id"] = ch_id
        case let ._fetchHTMLBookChapters(book_id):
            params["book_id"] = book_id
        case let ._fetchHTMLBookChapterContent(book_id, chapter_id):
            params["book_id"] = book_id
            params["chapter_id"] = chapter_id
        case let ._addBookMark(chapter_id, content, book_type,chapter_name,book_id):
            params["chapter_id"] = chapter_id
            params["content"] = content
            params["book_type"] = book_type
            params["chapter_name"] = chapter_name
            params["book_id"] = book_id
        case let ._fetchBookMarks(book_id):
            params["book_id"] = book_id
        case let ._deleteBookMark(marks):
            params["marks"] = marks
        case let ._buyEpub(book_id):
            params["book_id"] = book_id
        case let ._buyTxt(book_id, ch_id, count):
            params["book_id"] = book_id
            params["ch_id"] = ch_id
            params["count"] = count
        case let ._fetchTxtPrice(book_id, ch_id, count):
            params["book_id"] = book_id
            params["ch_id"] = ch_id
            params["count"] = count
        case let ._fetchEpubPrice(book_id):
            params["book_id"] = book_id
        case let ._saveUserRecord(book_id, last_chapter_id, schedule, book_type, book_name, book_cover, chapter_name):
            params["book_id"] = book_id
            params["last_chapter_id"] = last_chapter_id
            params["schedule"] = schedule
            params["book_type"] = book_type
            params["book_name"] = book_name
            params["book_cover"] = book_cover
            params["chapter_name"] = chapter_name
        }
        
        return params
    }
}

extension Router {
    
    fileprivate var urlRequest:URLRequest {
        
        let base = CJUserInfo.shared.baseUrl
        let path = self.path
        let urlString = base + path
        let url = URL(string: urlString)!
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        let parameters = self.parameters
        var param = [String]()
        for (key,value) in parameters {
            param.append("\(key)=\(value)")
        }
        let paramString = param.joined(separator: "&")
        
        urlRequest.httpBody = paramString.data(using: .utf8)
        
        return urlRequest
    }
    
}

enum YLLResponse<T> {
    case success(T?,String?)
    case cache(T?)
    case failure(String?,Int)
}

extension Router {

    //MARK:通用请求方法
    func request(_ requestResponse:((YLLResponse<JSONObject>)->Void)?) -> URLSessionTask? {
        
        let session = URLSession.shared
        let request = self.urlRequest
        
        let dataTask = session.dataTask(with: request) { (data, respose , error) in
            
            guard let resData = data else {
                DispatchQueue.main.async{requestResponse?(.failure("接口返回data为空",-1))}
                return
            }
            
            guard let resDic = try? JSONSerialization.jsonObject(with: resData, options: JSONSerialization.ReadingOptions.allowFragments) else {
                DispatchQueue.main.async{requestResponse?(.failure("json解析失败",-2))}
                return
            }
            
            guard let resObject = resDic as? JSONObject,!resObject.isEmpty else {
                DispatchQueue.main.async{requestResponse?(.failure("接口数据格式不正确",-3))}
                return
            }
            
            guard let code = resObject["code"] as? Int else {
                    DispatchQueue.main.async{requestResponse?(.failure("接口数据格式不正确",0))}
                    return
            }
            
            //返回的数据
            var responseData = resObject["data"] as? JSONObject
            if let responseData_ = resObject["data"] as? [JSONObject] {
                responseData = ["datas":responseData_]
            }
            
            let message = resObject["message"] as? String //message
            
            switch code {
            case 0:
                //成功，返回数据
                DispatchQueue.main.async {
                    requestResponse?(.success(responseData,message))
                    //如果需要缓存，则把responseData 转为jsonString保存到缓存 @TODO lidi
                }
            default:
                DispatchQueue.main.async{requestResponse?(.failure(message,code))}
            }
        }
        
        dataTask.resume()
        
        return dataTask
    }

}
