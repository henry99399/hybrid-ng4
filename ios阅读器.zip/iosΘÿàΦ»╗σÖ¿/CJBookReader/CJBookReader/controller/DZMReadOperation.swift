//
//  DZMReadOperation.swift
//  DZMeBookRead
//
//  Created by 邓泽淼 on 2017/5/15.
//  Copyright © 2017年 DZM. All rights reserved.
//

import UIKit

class DZMReadOperation: NSObject {

    /// 阅读控制器
    weak var vc:DZMReadController!
    
    // MARK: -- init
    
    init(vc:DZMReadController) {
        
        super.init()
        
        self.vc = vc
    }
    
    // MARK: -- 获取阅读控制器 DZMReadViewController
    
    /// 获取阅读View控制器
    private func GetReadViewController(readRecordModel:CJRecord?) -> DZMReadViewController? {
        
        if readRecordModel != nil {
            
            let readViewController = DZMReadViewController()
            
            readViewController.readRecordModel = readRecordModel
            
            readViewController.readController = vc
            
            return readViewController
        }
        
        return nil
    }
    
    /// 获取当前阅读记录的阅读View控制器
    func GetCurrentReadViewController(isUpdateFont:Bool = false, isSave:Bool = false) ->DZMReadViewController? {
        
        if isUpdateFont {
            vc.cjReadModel.record.updateFont(isSave: true)
        }
        
        if isSave {
            readRecordUpdate(readRecordModel: vc.cjReadModel.record)
        }
        
        let readRecordModel = vc.cjReadModel.record.copySelf()
        readRecordModel.updateFont()

        return GetReadViewController(readRecordModel: readRecordModel)
    }
    
    /// 获取上一页控制器
    func GetAboveReadViewController() ->DZMReadViewController? {
        
        // 阅读记录
        var readRecordModel:CJRecord?
        
        // 判断
        if vc.cjReadModel.isLocal { // 本地小说
            
            // 获得阅读记录
            readRecordModel = vc.cjReadModel.record.copySelf()
            readRecordModel?.updateFont()

            // 章节ID
            var id = ""
            if let txt = readRecordModel?.txtChapter {
                id = txt.ch_id
            }
            if let epub = readRecordModel?.epubChapter {
                id = epub.id
            }
            
            // 页码
            let page = readRecordModel!.page

            // 到头了
            
            if let _ = readRecordModel?.txtChapter {
                // 到头了
                if vc.cjReadModel.txtChapterList.first!.ch_id == id && page == 0 {return nil}
            }
            if let _ = readRecordModel?.epubChapter {
                // 到头了
                if vc.cjReadModel.epubChapterList.first!.id == id && page == 0 {return nil}
            }
            
            if let txt = readRecordModel?.txtChapter {
                if page == 0 { // 这一章到头了
                    
                    let currentIndex = txt.ch_index
                    let preChapter = vc.cjReadModel.txtChapterList[currentIndex - 1]
                    
                    if !preChapter.content.isEmpty {
                        readRecordModel?.txtChapter = preChapter
                        preChapter.updateFont()
                        readRecordModel?.page = preChapter.pageRanges.count - 1
                    } else {
                        self.loadContent(index: currentIndex - 1, callBack: nil)

//                        self.loadContent(index: currentIndex - 1, callBack:{ [weak self] in
//
//                            //加载完成，跳转到上一章的最后一页
//                            if let txtCp = self?.vc.cjReadModel.txtChapterList[currentIndex - 1] {
//                                txtCp.updateFont()
//                                self?.gotoChapter(chapterId: txtCp.ch_id, page: txtCp.pageRanges.count - 1)
//                            }
//                        })
                    }
                } else { // 没到头
                    readRecordModel?.page = page - 1
                }
                
            }

            if let epub = readRecordModel?.epubChapter {
                if page == 0 { // 这一章到头了
                    
                    let currentIndex = epub.ch_index
                    let preChapter = vc.cjReadModel.epubChapterList[currentIndex - 1]
                    
                    if !preChapter.content.isEmpty {
                        readRecordModel?.epubChapter = preChapter
                        readRecordModel?.epubChapter?.updateFont()
                        readRecordModel?.page = preChapter.pageCount - 1
                    } else {
                        self.loadContent(index: currentIndex - 1, callBack: nil)
//                        self.loadContent(index: currentIndex - 1, callBack:{ [weak self] in
//                            //加载完成，跳转到上一章的最后一页
//                            if let epubCp = self?.vc.cjReadModel.epubChapterList[currentIndex - 1] {
//                                epubCp.updateFont()
//                                self?.gotoChapter(chapterId: epubCp.id, page: epubCp.pageCount - 1)
//                            }
//                        })
                    }
                } else { // 没到头
                    readRecordModel?.page = page - 1
                }
            }
            
        } else { // 网络小说
            
            // 这里进行网络数据请求以及一些判断 当请求成功之后 使用(确保请求之后修改阅读记录模型)
            // vc.creatPageController(GetCurrentReadViewController())
            
            readRecordModel = nil
        }
        
        return GetReadViewController(readRecordModel: readRecordModel)
    }
    
    /// 获得下一页控制器
    func GetBelowReadViewController() -> DZMReadViewController? {
        
        // 阅读记录
        var readRecordModel:CJRecord?
        
        // 判断
        if vc.cjReadModel.isLocal { // 本地小说
            
            // 获得阅读记录
            readRecordModel = vc.cjReadModel.record.copySelf()
            readRecordModel?.updateFont()

            // 章节ID
            var id = ""
            if let txt = readRecordModel?.txtChapter {
                id = txt.ch_id
            }
            if let epub = readRecordModel?.epubChapter {
                id = epub.id
            }
            
            // 页码
            let page = readRecordModel!.page
            
            // 最后一页
            var lastPage = 0
            if let txt = readRecordModel?.txtChapter {
                lastPage = txt.pageRanges.count - 1
                // 到头了
                if vc.cjReadModel.txtChapterList.last!.ch_id == id && page == lastPage {
                    MBProgressHUD.showSuccess("已经是最后一页", to: self.vc.view, completion: nil)
                    return nil
                }
            }
            if let epub = readRecordModel?.epubChapter {
                lastPage = epub.pageCount - 1
                // 到头了
                if vc.cjReadModel.epubChapterList.last!.id == id && page == lastPage {
                    MBProgressHUD.showSuccess("已经是最后一页", to: self.vc.view, completion: nil)
                    return nil
                }
            }
            
            if let txt = readRecordModel?.txtChapter {
                if page == lastPage { // 这一章到头了
                    
                    let currentIndex = txt.ch_index
                    let nextChapter = vc.cjReadModel.txtChapterList[currentIndex + 1]
                    
                    if !nextChapter.content.isEmpty {
                        readRecordModel?.page = 0
                        readRecordModel?.txtChapter = nextChapter
                        nextChapter.updateFont()
                    } else {
                        self.loadContent(index: currentIndex + 1, callBack: nil)

//                        self.loadContent(index: currentIndex + 1, callBack: { [weak self] in
//                            //加载完成，直接跳到下一个章节
//                            self?.gotoChapter(chapterId: nextChapter.ch_id)
//                        })
                    }
                    
                } else { // 没到头
                    readRecordModel?.page = page + 1
                }
            }
            
            if let epub = readRecordModel?.epubChapter {
                if page == lastPage { // 这一章到头了
                    
                    let currentIndex = epub.ch_index
                    let nextChapter = vc.cjReadModel.epubChapterList[currentIndex + 1]
                    
                    if !nextChapter.content.isEmpty {
                        readRecordModel?.page = 0
                        readRecordModel?.epubChapter = nextChapter
                        nextChapter.updateFont()
                    } else {
                        self.loadContent(index: currentIndex + 1, callBack: nil)

//                        self.loadContent(index: currentIndex + 1, callBack: { [weak self] in
//                            //加载完成，直接跳到下一个章节
//                            self?.gotoChapter(chapterId: nextChapter.id)
//                        })
                    }
                    
                } else { // 没到头
                    readRecordModel?.page = page + 1
                }
            }
        }else{ // 网络小说
            
            // 这里进行网络数据请求以及一些判断 当请求成功之后 使用(确保请求之后修改阅读记录模型)
            // vc.creatPageController(GetCurrentReadViewController())
            
            readRecordModel = nil
        }
        
        return GetReadViewController(readRecordModel: readRecordModel)
    }
    
    /// 尝试跳转至章节，可能章节不存在，或者章节内容为空，需要请求网络
    func checkGoToChapter(chapterID:String) {
        
        if vc.cjReadModel.bookType == .txt {
            //判断章节是否存在
            var chapter:CJTxtChapter?
            var index:Int?
            for index_ in 0 ..< vc.cjReadModel.txtChapterList.count {
                let cp = vc.cjReadModel.txtChapterList[index_]
                if cp.ch_id == chapterID {
                    chapter = cp
                    index = index_
                    break
                }
            }
            
            if let chapter_ = chapter,let index_ = index {
                if chapter_.content.isEmpty {
                    self.loadContent(index: index_, callBack: {[weak self] in
                        self?.gotoChapter(chapterId: chapter_.ch_id)
                    })
                } else {
                    self.gotoChapter(chapterId: chapter_.ch_id)
                }
            }
        }
        
        if vc.cjReadModel.bookType == .epub {
            //判断章节是否存在
            var chapter:CJEpubChapter?
            var index:Int?
            for index_ in 0 ..< vc.cjReadModel.epubChapterList.count {
                let cp = vc.cjReadModel.epubChapterList[index_]
                if cp.id == chapterID {
                    chapter = cp
                    index = index_
                    break
                }
            }
            
            if let chapter_ = chapter,let index_ = index {
                if chapter_.content.isEmpty {
                    self.loadContent(index: index_, callBack: {[weak self] in
                        self?.gotoChapter(chapterId: chapter_.id)
                    })
                } else {
                    self.gotoChapter(chapterId: chapter_.id)
                }
            }
        }
        
    }
    
    ///已经判断章节存在，内容也存在，直接跳转至章节
    private func gotoChapter(chapterId:String,page:Int = 0) {
        self.vc.cjReadModel.modifyRecord(chapterID: chapterId,page: page)
        self.vc.creatPageController(self.GetCurrentReadViewController(isUpdateFont: true, isSave: true))
        self.vc.cjReadModel.uploadRecord()
    }
    
    // MARK: -- 同步记录 
    
    /// 更新记录
    func readRecordUpdate(readViewController:DZMReadViewController?, isSave:Bool = true) {
        self.readRecordUpdate(readRecordModel: readViewController?.readRecordModel, isSave: isSave)
    }
    
    /// 更新记录
    func readRecordUpdate(readRecordModel:CJRecord?, isSave:Bool = true) {
        
        if let record = readRecordModel {
            
            //判断是否切换了章节
            var needUploadRecord = false
            let preRec = self.vc.cjReadModel.record
            if let preCp = preRec.txtChapter ,let currentCp = record.txtChapter {
                if preCp.ch_id != currentCp.ch_id {
                    //需要上传
                    needUploadRecord = true
                }
            }
            
            if let preCp = preRec.epubChapter ,let currentCp = record.epubChapter {
                if preCp.id != currentCp.id {
                    //需要上传
                    needUploadRecord = true
                }
            }
            
            self.vc.cjReadModel.record = record
            
            if isSave {
                //上传阅读章节记录
                if needUploadRecord {
                    self.vc.cjReadModel.uploadRecord()
                }
                
                // 保存
                vc.cjReadModel.saveRecord()
                
                // 更新UI
                DispatchQueue.main.async { [weak self] ()->Void in
                    // 进度条数据初始化
                    self?.vc.readMenu.bottomView.sliderUpdate()
                }
                
            }
        }
    }
}

extension DZMReadOperation {
    
    //MARK: - 加载网络加载章节内容
    func loadContent(index:Int,callBack:(()->Void)?) {
        
        //加载当前章节
        MBProgressHUD.showMessage(to: self.vc.view)

        if vc.cjReadModel.bookType == .txt {
            
            let currentChapter = vc.cjReadModel.txtChapterList[index]
            
            _ = Router._fetchBookChapterContent(book_id: vc.cjReadModel.txtBookInfo.book_id, ch_id: currentChapter.ch_id).request({[weak self] (response) in
                
                MBProgressHUD.hideAllHUDs(for: self?.vc.view, animated: true)

                if case .success(let data ,_ ) = response {
                    if let content = data?["ch_content"] as? String {
                        currentChapter.content = content.filterTxt()
                        self?.vc.cjReadModel.saveChapters()
                        
                        callBack?()
                    }
                }
                if case .failure(_,let code) = response {
                    
                    if code == 600 {
                        //token 失效，跳转登陆界面
                        self?.vc.readMenu.jumpLogin()
                    }
                    
                    if let book = self?.vc.cjReadModel, code == 1 {
                        //需要购买章节
                        let payView = CJPayView(txt: book, chapterIndex: index, buyTxtSuccessCallback: { (startIndex, count) in

                            //刷新购买状态。  也可以直接跳转到购买的那个章节
                            for index_ in startIndex ..< (startIndex + count) {
                                if index_ < book.txtChapterList.count {
                                    book.txtChapterList[index_].is_buyed = true
                                } else {
                                    break
                                }
                            }
                            
                            //跳转到购买的那个章节
                            if startIndex < book.txtChapterList.count {
                                let chapter_ = book.txtChapterList[startIndex]
                                self?.checkGoToChapter(chapterID: chapter_.ch_id)
                            }
                            
                        })
                        payView.reChargeHandle = {[weak self] in
                            self?.vc.readMenu.recharge()
                        }
                        
                        payView.show()
                    }
                }
            })
                        
            //加载上一章节
            if index > 0 {
                let preIndex = index - 1
                let preChapter = vc.cjReadModel.txtChapterList[preIndex]
                
                if preChapter.content.isEmpty {
                    _ =
                        Router._fetchBookChapterContent(book_id: vc.cjReadModel.txtBookInfo.book_id, ch_id: preChapter.ch_id).request({ (response) in
                            
                            if case .success(let resData,_) = response {
                                if let content_ = resData?["ch_content"] as? String {
                                    preChapter.content = content_.filterTxt()
                                }
                            }
                            
                        })
                }
            }
            
            //加载下一章节
            if index < vc.cjReadModel.txtChapterList.count - 1 {
                let nextIndex = index + 1
                let nextChapter = vc.cjReadModel.txtChapterList[nextIndex]
                
                if nextChapter.content.isEmpty {
                    _ =
                        Router._fetchBookChapterContent(book_id: vc.cjReadModel.txtBookInfo.book_id, ch_id: nextChapter.ch_id).request({ (response) in
                            
                            if case .success(let resData,_) = response {
                                if let content_ = resData?["ch_content"] as? String {
                                    nextChapter.content = content_.filterTxt()
                                }
                            }
                            
                        })
                }
            }
        }
        
        if vc.cjReadModel.bookType == .epub {
            
            let currentChapter = vc.cjReadModel.epubChapterList[index]
            
            MBProgressHUD.showMessage(to: self.vc.view)
            
            _ = Router._fetchHTMLBookChapterContent(book_id: currentChapter.book_id, chapter_id: currentChapter.id).request({ (response) in
                
                MBProgressHUD.hideAllHUDs(for: self.vc.view, animated: true)
                
                if case .success(let data ,_ ) = response {
                    if let content = data?["content"] as? String {
                        currentChapter.content = content
                        self.vc.cjReadModel.saveChapters()

                        callBack?()
                    }
                }
                
                if case .failure(_,let code) = response {
                    if code == 1 {
                        //需要购买图书
                        let payView = CJPayView(epub: self.vc.cjReadModel, buyEpubSuccessCallback: { [weak self] in
                            
                            //刷新购买状态。也可以直接跳转到购买的那个章节
                            if let book = self?.vc.cjReadModel {
                                for index_ in 0 ..< book.epubChapterList.count {
                                    book.epubChapterList[index_].is_free = true
                                }
                                
                                //跳转到购买的那个章节
                                if index < book.epubChapterList.count {
                                    let chapter_ = book.epubChapterList[index]
                                    self?.checkGoToChapter(chapterID: chapter_.id)
                                }
                                
                            }
                        })
                        
                        payView.reChargeHandle = { [weak self] in
                            self?.vc.readMenu.recharge()
                        }
                        
                        payView.show()
                    }
                }
            })
            
            //加载上一章节
            if index > 0 {
                let preIndex = index - 1
                let preChapter = vc.cjReadModel.epubChapterList[preIndex]
                
                if preChapter.content.isEmpty {
                    _ =
                        Router._fetchHTMLBookChapterContent(book_id: preChapter.book_id, chapter_id: preChapter.id).request({ (response) in
                            
                            if case .success(let resData,_) = response {
                                if let content_ = resData?["content"] as? String {
                                    preChapter.content = content_
                                }
                            }
                            
                        })
                }
            }
            
            //加载下一章节
            if index < vc.cjReadModel.txtChapterList.count - 1 {
                let nextIndex = index + 1
                let nextChapter = vc.cjReadModel.epubChapterList[nextIndex]
                
                if nextChapter.content.isEmpty {
                    _ =
                        Router._fetchHTMLBookChapterContent(book_id: nextChapter.book_id, chapter_id: nextChapter.id).request({ (response) in
                            
                            if case .success(let resData,_) = response {
                                if let content_ = resData?["content"] as? String {
                                    nextChapter.content = content_
                                }
                            }
                            
                        })
                }
            }
        }
    }
}
