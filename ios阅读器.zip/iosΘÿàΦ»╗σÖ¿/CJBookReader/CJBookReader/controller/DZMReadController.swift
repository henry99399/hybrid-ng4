//
//  DZMReadController.swift
//  DZMeBookRead
//
//  Created by 邓泽淼 on 2017/5/11.
//  Copyright © 2017年 DZM. All rights reserved.
//

import UIKit

public class DZMReadController: DZMViewController,DZMReadMenuDelegate,DZMCoverControllerDelegate,UIPageViewControllerDelegate,UIPageViewControllerDataSource {
    
    var cjReadModel = CJBook()
    
    private var bookId = ""
    private var bookType = ""
    private var targetChapterId:String?
    
    /// 阅读菜单UI
    private(set) var readMenu:DZMReadMenu!
    
    /// 阅读操作对象
    private(set) var readOperation:DZMReadOperation!
    
    /// 翻页控制器 (仿真)
    private(set) var pageViewController:UIPageViewController?
    
    /// 翻页控制器 (无效果,覆盖)
    private(set) var coverController:DZMCoverController?
    
    /// 当前显示的阅读View控制器
    private(set) var currentReadViewController:DZMReadViewController?
    
    public convenience init(bookId:String,bookType:String,chapterId:String?) {
        self.init()
        self.bookId = bookId
        self.bookType = bookType
        self.targetChapterId = chapterId
    }
    
    public override func viewDidLoad() {
        
        super.viewDidLoad()
        
        // 设置白色状态栏
        isStatusBarLightContent = true
        
        // 初始化控制器操作对象
        readOperation = DZMReadOperation(vc: self)
        
        // 初始化阅读UI控制对象
        readMenu = DZMReadMenu.readMenu(vc: self, delegate: self)
        
        // 初始化控制器
        creatPageController(readOperation.GetCurrentReadViewController(isUpdateFont: true, isSave: true))
        
        //监听是否触发home键挂起程序.
        NotificationCenter.default.addObserver(self, selector: #selector(self.applicationWillResignActive), name: NSNotification.Name.UIApplicationWillResignActive, object: nil)
        
        ///监听是否重新进入程序程序.
        NotificationCenter.default.addObserver(self, selector: #selector(self.applicationDidBecomeActive), name: NSNotification.Name.UIApplicationDidBecomeActive, object: nil)
        ///监听是否被kill
        NotificationCenter.default.addObserver(self, selector: #selector(self.applicationWillTerminate), name: NSNotification.Name.UIApplicationWillTerminate, object: nil)
        
        self.loadBook()
    }
    
    func applicationWillResignActive(){
        print("监听是否触发home键挂起程序.")
        readMenu.lightView.reSetSystemBrightness()
    }
    
    func applicationDidBecomeActive(){
        print("监听是否重新进入程序程序.")
        readMenu.lightView.reSetCustomBrightness()
    }
    
    func applicationWillTerminate(){
        print("监听是否进入后台或被kill")
    }
    
    func loadBook() {
        //加载书籍
        //检查图书是否已经下载，已经下载直接读取本地数据
        
        //网络请求书本信息
        
        //epub
        if self.bookType == "2" {
            
            MBProgressHUD.showMessage(to: self.view)

            _ = Router._fetchHTMLBookChapters(book_id: self.bookId).request {[weak self] (response) in
                
                MBProgressHUD.hide(for: self?.view, animated: true)
                
                if case .success(let resData,_) = response {
                    let readModel = CJBook(epubJson: resData)
                    
                    self?.cjReadModel = readModel
                    self?.loadMarks()

                    if readModel.epubChapterList.isEmpty {
                        //图书没有章节
                        return
                    }
                    
                    //判断需要跳转的章节
                    var targetChapter:CJEpubChapter?
                    if let targetCpId = self?.targetChapterId {
                        for cp in readModel.epubChapterList {
                            if cp.id == targetCpId {
                                targetChapter = cp
                                break
                            }
                        }
                    }
                    
                    //先直接加载阅读记录
                    if let recordChapter = readModel.record.epubChapter {
                        self?.readOperation.checkGoToChapter(chapterID: recordChapter.id)
                    }
                    
                    //然后直接跳转章节
                    if let targetChapter_ = targetChapter {
                        self?.readOperation.checkGoToChapter(chapterID: targetChapter_.id)
                    }
                }
                
                if case .failure(_ ,let code) = response {
                    if code == 600 {
                        //token 失效，跳转登陆界面
                        self?.readMenu.jumpLogin()
                    }
                }
            }
        }
        
        //网文
        if self.bookType == "1" {
            
            MBProgressHUD.showMessage(to: self.view)

            _ = Router._fetchBookChapters(book_id: self.bookId).request {[weak self] (response) in
                
                MBProgressHUD.hide(for: self?.view, animated: true)

                if case .success(let resData,_) = response {
                    let readModel = CJBook(txtJson: resData)
                    
                    self?.cjReadModel = readModel
                    self?.loadMarks()
                    
                    if readModel.txtChapterList.isEmpty {
                        //网文没有章节
                        return
                    }
                    
                    //判断需要跳转的章节
                    var targetChapter:CJTxtChapter?
                    if let targetCpId = self?.targetChapterId {
                        for cp in readModel.txtChapterList {
                            if cp.ch_id == targetCpId {
                                targetChapter = cp
                                break
                            }
                        }
                    }
                    
                    //先直接加载阅读记录
                    if let recordChapter = readModel.record.txtChapter {
                        self?.readOperation.checkGoToChapter(chapterID: recordChapter.ch_id)
                    }
                    
                    //然后直接跳转章节
                    if let targetChapter_ = targetChapter {
                        self?.readOperation.checkGoToChapter(chapterID: targetChapter_.ch_id)
                    }
                }
                
                if case .failure(_ ,let code) = response {
                    if code == 600 {
                        //token 失效，跳转登陆界面
                        self?.readMenu.jumpLogin()
                    }
                }
            }
        }
    }
    
    func loadMarks() {
        //加载书签
        _ = Router._fetchBookMarks(book_id: self.bookId).request {[weak self] (response) in
            if case .success(let res,_) = response {
                if let markObjects = res?["datas"] as? [JSONObject] {
                    
                    var marks = [CJMark]()
                    for index in 0 ..< markObjects.count {
                        let obj = markObjects[index]
                        let mark = CJMark()
                        if let value = obj["mark_id"] as? Int {
                            mark.mark_id = String(value)
                        }
                        if let value = obj["mark_id"] as? String {
                            mark.mark_id = value
                        }
                        if mark.mark_id.isEmpty {
                            continue
                        }
                        
                        if let value = obj["chapter_id"] as? Int {
                            mark.chapter_id = String(value)
                        }
                        if let value = obj["chapter_id"] as? String {
                            mark.chapter_id = value
                        }
                        
                        if let value = obj["content"] as? String {
                            mark.content = value
                        }
                        
                        if let value = obj["name"] as? String {
                            mark.name = value
                        }
                        
                        if let value = obj["create_time"] as? String {
                            let dateformat = DateFormatter()
                            dateformat.dateFormat = "yyyy-MM-dd HH:mm:ss"
                            if let time = dateformat.date(from: value)?.timeIntervalSince1970 {
                                mark.create_time = time
                            }
                        }
                        
                        marks.append(mark)
                    }
                    
                    if let marks_ = self?.cjReadModel.marks ,marks_.isEmpty {
                        self?.cjReadModel.marks = marks
                    }
                }
            }
        }
    }
    
    // MARK: -- DZMReadMenuDelegate
    
    /// 背景颜色
    func readMenuClickSetuptColor(readMenu: DZMReadMenu, index: NSInteger, color: UIColor) {
        
        DZMReadConfigure.shared().colorIndex = index
        
        //切换到白天模式
        self.readMenu.lightButton.isSelected = false
        DZMUserDefaults.setBool(false, key: DZMKey_IsNighOrtDay)

        currentReadViewController?.configureBGColor()
    }
    
    /// 翻书动画
    func readMenuClickSetuptEffect(readMenu: DZMReadMenu, index: NSInteger) {
        
        DZMReadConfigure.shared().effectType = index
        
        creatPageController(readOperation.GetCurrentReadViewController())
    }
    
    /// 字体
    func readMenuClickSetuptFont(readMenu: DZMReadMenu, index: NSInteger) {
        
        DZMReadConfigure.shared().fontType = index
        
        creatPageController(readOperation.GetCurrentReadViewController(isUpdateFont: true, isSave: true))
    }
    
    /// 字体大小
    func readMenuClickSetuptFontSize(readMenu: DZMReadMenu, fontSize: CGFloat) {
        
        // DZMReadConfigure.shared().fontSize = fontSize 内部已赋值
        
        creatPageController(readOperation.GetCurrentReadViewController(isUpdateFont: true, isSave: true))
    }
    
    
    /// 点击返回按钮
    func readMenuClickBackButton(readMenu: DZMReadMenu, button: UIButton) {
        print("点击返回按钮-------")
     
        readMenu.lightView.reSetSystemBrightness()
    }

    /// 点击书签列表
    func readMenuClickMarkList(readMenu: DZMReadMenu, readMarkModel: CJMark) {
        
        if self.cjReadModel.bookType == .txt {
            
            var targetChapter:CJTxtChapter?
            for chapter in self.cjReadModel.txtChapterList {
                if chapter.ch_id == readMarkModel.chapter_id {
                    targetChapter = chapter
                    break
                }
            }
            
            if let targetChapter_ = targetChapter {
                let page = targetChapter_.pageFor(location: readMarkModel.location)
                self.cjReadModel.record.page = page
                self.cjReadModel.record.txtChapter = targetChapter_
            }
        }
        
        if self.cjReadModel.bookType == .epub {
            var targetChapter:CJEpubChapter?
            for chapter in self.cjReadModel.epubChapterList {
                if chapter.id == readMarkModel.chapter_id {
                    targetChapter = chapter
                    break
                }
            }
            
            if let targetChapter_ = targetChapter {
                let page = readMarkModel.location
                self.cjReadModel.record.page = page
                self.cjReadModel.record.epubChapter = targetChapter_
            }
        }
        
        self.creatPageController(readOperation.GetCurrentReadViewController(isUpdateFont: false, isSave: true))
    }
    
    /// 下载
    func readMenuClickDownload(readMenu: DZMReadMenu) {
        
        print("点击了下载")
    }
    
    /// 拖拽进度条
    func readMenuSliderEndScroll(readMenu: DZMReadMenu, slider: ASValueTrackingSlider) {
        let toPage = Int(slider.value)
        if self.cjReadModel.record.page != toPage {
            self.cjReadModel.record.page = toPage
            let page = self.readOperation.GetCurrentReadViewController(isUpdateFont: true,isSave: true)
            self.creatPageController(page)
        }
    }
    
    /// 上一章
    func readMenuClickPreviousChapter(readMenu: DZMReadMenu) {
        var currentIndex = 0
        if let txt = self.cjReadModel.record.txtChapter {
            currentIndex = txt.ch_index
        }
        
        if let epub = self.cjReadModel.record.epubChapter {
            currentIndex = epub.ch_index
        }
        
        let preIndex = currentIndex - 1
        if preIndex >= 0 {
            
            var chapterId = ""
            switch self.cjReadModel.bookType {
            case .txt:
                chapterId = self.cjReadModel.txtChapterList[preIndex].ch_id
            case .epub:
                chapterId = self.cjReadModel.epubChapterList[preIndex].id
            }
            
            self.readOperation.checkGoToChapter(chapterID: chapterId)
        }
    }
    
    /// 下一章
    func readMenuClickNextChapter(readMenu: DZMReadMenu) {
        var currentIndex = 0
        if let txt = self.cjReadModel.record.txtChapter {
            currentIndex = txt.ch_index
        }
        
        if let epub = self.cjReadModel.record.epubChapter {
            currentIndex = epub.ch_index
        }
        
        let nextIndex = currentIndex + 1
        
        if self.cjReadModel.bookType == .txt && nextIndex >= self.cjReadModel.txtChapterList.count {
            return
        }
        
        if self.cjReadModel.bookType == .epub && nextIndex >= self.cjReadModel.epubChapterList.count {
            return
        }
        
        var chapterId = ""
        switch self.cjReadModel.bookType {
        case .txt:
            chapterId = self.cjReadModel.txtChapterList[nextIndex].ch_id
        case .epub:
            chapterId = self.cjReadModel.epubChapterList[nextIndex].id
        }
        self.readOperation.checkGoToChapter(chapterID: chapterId)
    }
    
    /// 点击章节列表
    func readMenuClickTxtChapterList(readMenu: DZMReadMenu, readChapterListModel: CJTxtChapter) {
        self.readOperation.checkGoToChapter(chapterID: readChapterListModel.ch_id)
    }
    
    func readMenuClickEpubChapterList(readMenu: DZMReadMenu, readChapterListModel: CJEpubChapter) {
        self.readOperation.checkGoToChapter(chapterID: readChapterListModel.id)
    }
    
    /// 切换日夜间模式
    func readMenuClickLightButton(readMenu: DZMReadMenu, isDay: Bool) {
        
        if isDay {
            currentReadViewController?.configureNightBGColor()
            currentReadViewController?.tableView.reloadData()
        }else{
            currentReadViewController?.configureBGColor()
            currentReadViewController?.tableView.reloadData()
            
        }
    }
    
    /// 状态栏 将要 - 隐藏以及显示状态改变
    func readMenuWillShowOrHidden(readMenu: DZMReadMenu, isShow: Bool) {
        
        pageViewController?.tapGestureRecognizerEnabled = !isShow
        
        coverController?.tapGestureRecognizerEnabled = !isShow
        
        if isShow {
            
            // 选中章节列表
            //readMenu.leftView.topView.selectIndex = 0
            
            // 检查当前是否存在书签
            readMenu.topView.mark.isSelected = self.cjReadModel.isMarkExist(readRecord: self.cjReadModel.record)
        }
    }
    
    /// 点击书签按钮
    func readMenuClickMarkButton(readMenu: DZMReadMenu, button: UIButton) {
        if button.isSelected {
            self.cjReadModel.deleteReadmark(readMark: nil, index: nil, callback: { [weak self] in
                if let weakSelf = self {
                    button.isSelected = weakSelf.cjReadModel.isMarkExist(readRecord: weakSelf.cjReadModel.record)
                }
            })
        } else {
            
            //添加书签
            var chapter_id = ""
            var content = ""
            var book_type = ""
            var chapter_name = ""
            var book_id = ""
            if self.cjReadModel.bookType == .txt {
                book_type = "1"
                book_id = self.cjReadModel.txtBookInfo.book_id
                if let txt = self.cjReadModel.record.txtChapter {
                    chapter_id = txt.ch_id
                    let range = txt.pageRanges[self.cjReadModel.record.page]
                    content = txt.content.substring(range)
                    chapter_name = txt.ch_name
                }
            } else {
                book_type = "2"
                book_id = self.cjReadModel.epubBookInfo.book_id
                if let epub = self.cjReadModel.record.epubChapter {
                    chapter_id = epub.id
                    content = epub.contentFor(page: self.cjReadModel.record.page)
                    chapter_name = epub.name
                }
            }
            
            if !chapter_id.isEmpty {
                
                MBProgressHUD.showMessage(to: self.view)
                
                _ = Router._addBookMark(chapter_id: chapter_id, content: content, book_type: book_type,chapter_name: chapter_name,book_id: book_id).request({[weak self] (response) in
                    
                    MBProgressHUD.hideAllHUDs(for: self?.view, animated: true)
                    
                    if case .success(let res,_) = response {
                        if let weakSelf = self {
                            var markId = ""
                            if let markId_ = res?["mark_id"] as? Int {
                                markId = String(markId_)
                            }
                            
                            if let markId_ = res?["mark_id"] as? String {
                                markId = markId_
                            }
                            
                            if !markId.isEmpty {
                                weakSelf.cjReadModel.addRemark(readRecord: weakSelf.cjReadModel.record,markId: markId)
                                button.isSelected = weakSelf.cjReadModel.isMarkExist(readRecord: weakSelf.cjReadModel.record)
                            }
                        }
                    }
                    
                    if case .failure(let message,let code) = response {
                        if code == 600 {
                            self?.readMenu.jumpLogin()
                        } else {
                            MBProgressHUD.showError(message, to: self?.view)
                        }
                    }
                })
            }
        }
    }
    
    // MARK: -- 创建 PageController
    
    /// 创建效果控制器 传入初始化显示控制器
    func creatPageController(_ displayController:UIViewController?) {
        
        // 清理
        if pageViewController != nil {
            
            pageViewController?.view.removeFromSuperview()
            
            pageViewController?.removeFromParentViewController()
            
            pageViewController = nil
        }
        
        if coverController != nil {
            
            coverController?.view.removeFromSuperview()
            
            coverController?.removeFromParentViewController()
            
            coverController = nil
        }
        
        // 创建
        if DZMReadConfigure.shared().effectType == DZMRMEffectType.simulation.rawValue { // 仿真
            
            let options = [UIPageViewControllerOptionSpineLocationKey:NSNumber(value: UIPageViewControllerSpineLocation.min.rawValue as Int)]
            
            pageViewController = UIPageViewController(transitionStyle:UIPageViewControllerTransitionStyle.pageCurl,navigationOrientation:UIPageViewControllerNavigationOrientation.horizontal,options: options)
            
            pageViewController!.delegate = self
            
            pageViewController!.dataSource = self
            
            // 为了翻页背面的颜色使用
            pageViewController!.isDoubleSided = true
            
            view.insertSubview(pageViewController!.view, at: 0)
            
            addChildViewController(pageViewController!)
            
            pageViewController!.setViewControllers((displayController != nil ? [displayController!] : nil), direction: UIPageViewControllerNavigationDirection.forward, animated: true, completion: nil)
            
        }else{ // 无效果 覆盖
            
            coverController = DZMCoverController()
            
            coverController!.delegate = self
            
            view.insertSubview(coverController!.view, at: 0)
            
            addChildViewController(coverController!)
            
            coverController!.setController(displayController)
            
            if DZMReadConfigure.shared().effectType == DZMRMEffectType.none.rawValue {
                
                coverController!.openAnimate = false
                
            }
        }
        
        if self.cjReadModel.bookType == .txt {
            readMenu.topView.setTitle(self.cjReadModel.record.txtChapter?.ch_name)
        } else {
            readMenu.topView.setTitle(self.cjReadModel.record.epubChapter?.name)
        }
        // 记录
        currentReadViewController = displayController as? DZMReadViewController
    }
    
    // MARK: -- DZMCoverControllerDelegate
    
    /// 切换结果
    public func coverController(_ coverController: DZMCoverController, currentController: UIViewController?, finish isFinish: Bool) {
        
        // 记录
        currentReadViewController = currentController as? DZMReadViewController
        
        // 更新阅读记录
        readOperation.readRecordUpdate(readViewController: currentReadViewController)
        
        // 更新进度条
        readMenu.bottomView.sliderUpdate()
    }
    
    /// 将要显示的控制器
    public func coverController(_ coverController: DZMCoverController, willTransitionToPendingController pendingController: UIViewController?) {
        readMenu.menuSH(isShow: false)
    }
    
    /// 获取上一个控制器
    public func coverController(_ coverController: DZMCoverController, getAboveControllerWithCurrentController currentController: UIViewController?) -> UIViewController? {
        return readOperation.GetAboveReadViewController()
    }
    
    /// 获取下一个控制器
    public func coverController(_ coverController: DZMCoverController, getBelowControllerWithCurrentController currentController: UIViewController?) -> UIViewController? {
        return readOperation.GetBelowReadViewController()
    }
    
    // MARK: -- UIPageViewControllerDelegate
    
    /// 切换结果
    public func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        
        if !completed {
            
            // 记录
            currentReadViewController = previousViewControllers.first as? DZMReadViewController
            
            // 更新阅读记录
            readOperation.readRecordUpdate(readViewController: currentReadViewController)
            
        }else{
            
            // 记录
            currentReadViewController = pageViewController.viewControllers?.first as? DZMReadViewController
            
            // 更新阅读记录
            readOperation.readRecordUpdate(readViewController: currentReadViewController)
            
            // 更新进度条
            readMenu.bottomView.sliderUpdate()
        }
    }
    
    /// 准备切换
    public func pageViewController(_ pageViewController: UIPageViewController, willTransitionTo pendingViewControllers: [UIViewController]) {
        
        readMenu.menuSH(isShow: false)
        
        // 更新阅读记录 colin
        readOperation.readRecordUpdate(readViewController: pageViewController.viewControllers?.first as? DZMReadViewController, isSave: false)
    }
    
    
    // MARK: -- UIPageViewControllerDataSource
    
    /// 用于区分正反面的值(固定)
    private var TempNumber:NSInteger = 1
    
    /// 获取上一页
    public func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        
        TempNumber -= 1
        
        if abs(TempNumber) % 2 == 0 { // 背面
            
            let vc = UIViewController()
            // 配置背景颜色
            if DZMUserDefaults.boolForKey(DZMKey_IsNighOrtDay) {
                vc.view.backgroundColor =  DZMReadHeaderAndFooterTextColor_NIGHT
            }else{
                vc.view.backgroundColor =  DZMReadConfigure.shared().readColor()
            }
            return vc
            
        } else { // 内容
            return readOperation.GetAboveReadViewController()
        }
    }
    
    /// 获取下一页
    public func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        
        TempNumber += 1
        
        if abs(TempNumber) % 2 == 0 { // 背面
            
            let vc = UIViewController()
            
            // 配置背景颜色
            if DZMUserDefaults.boolForKey(DZMKey_IsNighOrtDay) {
                vc.view.backgroundColor =  DZMReadHeaderAndFooterTextColor_NIGHT
            }else{
                vc.view.backgroundColor =  DZMReadConfigure.shared().readColor()
            }
            return vc
            
        }else{ // 内容
            return readOperation.GetBelowReadViewController()
        }
    }
    
    deinit {
        // 清理模型
        //self.cjReadModel = nil
    }
}
