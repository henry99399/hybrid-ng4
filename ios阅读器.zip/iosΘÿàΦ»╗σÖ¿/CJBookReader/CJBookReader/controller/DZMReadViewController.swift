//
//  DZMReadViewController.swift
//  DZMeBookRead
//
//  Created by 邓泽淼 on 2017/5/12.
//  Copyright © 2017年 DZM. All rights reserved.
//

import UIKit

class DZMReadViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    /// 临时阅读记录
    var readRecordModel:CJRecord!
    
    /// 阅读控制器
    weak var readController:DZMReadController!
    
    /// 顶部状态栏
    private(set) var topStatusView:UILabel!
    
    /// 底部状态栏
    private(set) var bottomStatusView:DZMRMStatusView!
    
    /// TableView
    private(set) var tableView:UITableView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        // 添加子控件
        addSubviews()
        
        // 配置背景颜色
        if DZMUserDefaults.boolForKey(DZMKey_IsNighOrtDay) {
            configureNightBGColor()
        }else{
            configureBGColor()
        }
        
        // 配置阅读模式
        configureReadEffect()
        
        // 配置阅读记录
        //configureReadRecordModel()
    }
    
    /// 创建UI
    func addSubviews() {
        
        // TopStatusView
        topStatusView = UILabel()
        if let txt = readRecordModel.txtChapter {
            topStatusView.text = txt.ch_name
        }
        if let epub = readRecordModel.epubChapter {
            topStatusView.text = epub.name
        }
        topStatusView.lineBreakMode = .byTruncatingMiddle
        topStatusView.textColor = DZMColor_4
        topStatusView.font = DZMFont_12
        topStatusView.frame = CGRect(x: DZMSpace_1, y: 0, width: view.width - 2 * DZMSpace_1, height: DZMSpace_2)
        view.addSubview(topStatusView)
        
        // BottomStatusView
        bottomStatusView = DZMRMStatusView(frame:CGRect(x: DZMSpace_1, y: view.frame.height - DZMSpace_2, width: view.width - 2 * DZMSpace_1, height: DZMSpace_2))
        bottomStatusView.backgroundColor = UIColor.clear
        
        if let txt = readRecordModel.txtChapter {
            bottomStatusView.titleLabel.text = "\(readRecordModel.page + 1)/\(txt.pageRanges.count)"
        }
        if let epub = readRecordModel.epubChapter {
            bottomStatusView.titleLabel.text = "\(readRecordModel.page + 1)/\(epub.pageCount)"
        }
        
        view.addSubview(bottomStatusView)
        
        // UITableView
        tableView = UITableView()
        tableView.backgroundColor = UIColor.clear
        tableView.showsVerticalScrollIndicator = false
        tableView.separatorStyle = .none
        tableView.delegate = self
        tableView.dataSource = self
        tableView.frame = GetReadTableViewFrame()
        view.addSubview(tableView)
        
        // 清理
        /*
        for readChapterListModel in readController.readModel.readChapterListModels {
            readChapterListModel.clearPageCount(readRecordModel: readRecordModel)
        }
         */
    }
    
    // MARK: -- 配置背景颜色

    /// 配置背景颜色
    func configureBGColor() {
        view.backgroundColor = DZMReadConfigure.shared().readColor()
        bottomStatusView.setColors(textColor: DZMReadConfigure.shared().readHeaderAndFooterColor())
        topStatusView.textColor = DZMReadConfigure.shared().readHeaderAndFooterColor()
    }
    
    /// 配置夜间背景颜色
    func configureNightBGColor() {
        view.backgroundColor = DZMReadBGColor_NIGHT
        bottomStatusView.setColors(textColor: DZMReadTextColor_NIGHT)
        topStatusView.textColor = DZMReadHeaderAndFooterTextColor_NIGHT
    }
    
    // MARK: -- 阅读模式
    
    /// 配置阅读效果
    func configureReadEffect() {
        tableView.isScrollEnabled = false
    }
    
    // MARK: -- UITableViewDelegate,UITableViewDataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = DZMReadViewCell.cellWithTableView(tableView)
        if let txt = readRecordModel.txtChapter {
            cell.frameRef = txt.frameRefFor(page: readRecordModel.page)
        }
        
        if let epub = readRecordModel.epubChapter {
            cell.frameRef = epub.frameFor(page: readRecordModel.page)
        }
        
        cell.readController = self.readController
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return GetReadTableViewFrame().height
    }
    
    deinit {
        
        // 释放该临时模型
        readRecordModel = nil
        
        // 移除定时器
        bottomStatusView?.removeTimer()
    }
}
