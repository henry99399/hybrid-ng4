//
//  CJChapter.swift
//  AHQBookRead
//
//  Created by lidi on 2017/10/27.
//  Copyright © 2017年 ahq. All rights reserved.
//

import Foundation

//网文章节
class CJTxtChapter: NSObject,NSSecureCoding {
    
    var ch_id = ""
    var ch_index = 0
    var ch_name = ""
    var ch_sale = 0.0
    var ch_update = ""
    var ch_vip = ""
    var is_buyed = false
    
    var content = "" {
        didSet {
            if oldValue != self.content {
                self.updateFont()
            }
        }
    }
    
    override init() {
        super.init()
    }
    
    //网文
    init(txtJson:JSONObject?) {
        super.init()
        if let value = txtJson?["ch_id"] as? String {
            self.ch_id = value
        }
        if let value = txtJson?["ch_index"] as? Int {
            self.ch_index = value
        }
        if let value = txtJson?["ch_name"] as? String {
            self.ch_name = value
        }
        if let value = txtJson?["ch_sale"] as? Double {
            self.ch_sale = value
        }
        if let value = txtJson?["ch_update"] as? String {
            self.ch_update = value
        }
        if let value = txtJson?["ch_vip"] as? String {
            self.ch_vip = value
        }
        
        if let value = txtJson?["is_buyed"] as? Int {
            self.is_buyed = value > 0
        }
        if let value = txtJson?["is_buyed"] as? Bool {
            self.is_buyed = value
        }
    }
    
    //MARK: - NSSecureCoding
    static var supportsSecureCoding: Bool = true
    
    required init?(coder aDecoder: NSCoder) {
        super.init()
        
        if let value = aDecoder.decodeObject(forKey: "ch_id") as? String {
            self.ch_id = value
        }
        
        self.ch_index = aDecoder.decodeInteger(forKey: "ch_index")
        
        if let value = aDecoder.decodeObject(forKey: "ch_name") as? String {
            self.ch_name = value
        }
        
        self.ch_sale = aDecoder.decodeDouble(forKey: "ch_sale")
        
        if let value = aDecoder.decodeObject(forKey: "ch_update") as? String {
            self.ch_update = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "ch_vip") as? String {
            self.ch_vip = value
        }
        
        self.is_buyed = aDecoder.decodeBool(forKey: "is_buyed")
        
        if let value = aDecoder.decodeObject(forKey: "content") as? String {
            self.content = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "pageRanges") as? [NSRange] {
            self.pageRanges = value
        }
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(self.ch_id, forKey: "ch_id")
        aCoder.encode(self.ch_index, forKey: "ch_index")
        aCoder.encode(self.ch_name, forKey: "ch_name")
        aCoder.encode(self.ch_sale, forKey: "ch_sale")
        aCoder.encode(self.ch_update, forKey: "ch_update")
        aCoder.encode(self.ch_vip, forKey: "ch_vip")
        aCoder.encode(self.is_buyed, forKey: "is_buyed")
        aCoder.encode(self.content, forKey: "content")
        aCoder.encode(self.pageRanges,forKey:"pageRanges")
    }
    
    var pageRanges = [NSRange]() //分页
    
    // MARK: -- 更新字体
    
    /// 记录该章使用的字体属性
    private var readAttribute:[String:NSObject] = [:]
    
    /// 更新字体
    func updateFont(isSave:Bool = false) {
        
        let readAttribute = DZMReadConfigure.shared().readAttribute()
        
        if self.readAttribute != readAttribute || self.pageRanges.count <= 1 {
            
            self.readAttribute = readAttribute
            
            let rect = GetReadViewFrame()
            
            // 记录
            var rangeArray:[NSRange] = []
            
            // 拼接字符串
            let attrString = NSMutableAttributedString(string: self.content, attributes: self.readAttribute)
            
            let frameSetter = CTFramesetterCreateWithAttributedString(attrString as CFAttributedString)
            
            let path = CGPath(rect: rect, transform: nil)
            
            var range = CFRangeMake(0, 0)
            
            var rangeOffset:NSInteger = 0
            
            repeat {
                let frame = CTFramesetterCreateFrame(frameSetter, CFRangeMake(rangeOffset, 0), path, nil)
                range = CTFrameGetVisibleStringRange(frame)
                rangeArray.append(NSMakeRange(rangeOffset, range.length))
                rangeOffset += range.length
            } while (range.location + range.length < attrString.length)
            
            
            self.pageRanges = rangeArray
        }
    }
    
    func frameRefFor(page:Int) -> CTFrame {
        
        let rect = GetReadViewFrame()
        let pageRange = self.pageRanges[page]
        let pageContent = self.content.substring(pageRange)
        let attributedString = NSMutableAttributedString(string: pageContent,attributes: self.readAttribute)
        let framesetter = CTFramesetterCreateWithAttributedString(attributedString)
        let path = CGPath(rect: rect, transform: nil)
        let frameRef = CTFramesetterCreateFrame(framesetter, CFRangeMake(0, 0), path, nil)
        
        return frameRef
    }
    
    /// 通过 Location 获得 Page
    func pageFor(location:Int) -> Int {
        let count = self.pageRanges.count
        for index in 0 ..< count {
            let range = self.pageRanges[index]
            if location < (range.location + range.length) {
                return index
            }
        }
        return 0
    }
    
}

//电子书章节
class CJEpubChapter: NSObject,NSSecureCoding {
    
    var book_id = ""
    var ch_index = 0
    var child = [CJEpubChapter]()
    var code = ""
    var create_time = ""
    var end_page = ""
    var format = ""
    var id = ""
    var is_free = true
    var name = ""
    var path = ""
    var pdf_page = ""
    var pid = ""
    var pname = ""
    var purl = ""
    var start_page = 0
    var url = ""
    
    /// 内容
    var content = "" {
        didSet {
            self.parthHTMLContent()
        }
    }
    
    override init() {
        super.init()
    }
    
    init(epubJson:JSONObject?) {
        if let value = epubJson?["book_id"] as? String {
            self.book_id = value
        }
        if let value = epubJson?["book_id"] as? Int {
            self.book_id = String(value)
        }
        
        var child_ = [CJEpubChapter]()
        if let value = epubJson?["child"] as? [JSONObject] {
            for index in 0 ..< value.count {
                let temp = CJEpubChapter(epubJson: value[index])
                child_.append(temp)
            }
        }
        self.child = child_
        
        if let value = epubJson?["code"] as? String {
            self.code = value
        }
        if let value = epubJson?["create_time"] as? String {
            self.create_time = value
        }
        if let value = epubJson?["end_page"] as? String {
            self.end_page = value
        }
        if let value = epubJson?["format"] as? String {
            self.format = value
        }
        
        if let value = epubJson?["id"] as? String {
            self.id = value
        }
        if let value = epubJson?["id"] as? Int {
            self.id = String(value)
        }
        
        if let value = epubJson?["is_free"] as? Bool {
            self.is_free = value
        }
        if let value = epubJson?["is_free"] as? Int {
            self.is_free = value > 0
        }
        
        if let value = epubJson?["name"] as? String {
            self.name = value
        }
        if let value = epubJson?["path"] as? String {
            self.path = value
        }
        if let value = epubJson?["pdf_page"] as? String {
            self.pdf_page = value
        }
        
        if let value = epubJson?["pid"] as? String {
            self.pid = value
        }
        if let value = epubJson?["pid"] as? Int {
            self.pid = String(value)
        }
        
        if let value = epubJson?["pname"] as? String {
            self.pname = value
        }
        if let value = epubJson?["purl"] as? String {
            self.purl = value
        }
        if let value = epubJson?["start_page"] as? Int {
            self.start_page = value
        }
        if let value = epubJson?["url"] as? String {
            self.url = value
        }

    }
    
    //MARK: - NSSecureCoding
    static var supportsSecureCoding: Bool = true
    
    required init?(coder aDecoder: NSCoder) {
        super.init()
        
        if let value = aDecoder.decodeObject(forKey: "book_id") as? String {
            self.book_id = value
        }
        
        self.ch_index = aDecoder.decodeInteger(forKey: "ch_index")
        
        if let value = aDecoder.decodeObject(forKey: "child") as? [CJEpubChapter] {
            self.child = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "code") as? String {
            self.code = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "create_time") as? String {
            self.create_time = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "end_page") as? String {
            self.end_page = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "format") as? String {
            self.format = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "id") as? String {
            self.id = value
        }
        
        self.is_free = aDecoder.decodeBool(forKey: "is_free")
        
        if let value = aDecoder.decodeObject(forKey: "name") as? String {
            self.name = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "path") as? String {
            self.path = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "pdf_page") as? String {
            self.pdf_page = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "pid") as? String {
            self.pid = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "pname") as? String {
            self.pname = value
        }
        
        if let value = aDecoder.decodeObject(forKey: "purl") as? String {
            self.purl = value
        }
        
        self.start_page = aDecoder.decodeInteger(forKey: "start_page")
        
        if let value = aDecoder.decodeObject(forKey: "url") as? String {
            self.url = value
        }
        if let value = aDecoder.decodeObject(forKey: "content") as? String {
            self.content = value
            self.parthHTMLContent()
        }
        
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(self.book_id, forKey: "book_id")
        aCoder.encode(self.ch_index, forKey: "ch_index")
        aCoder.encode(self.child, forKey: "child")
        aCoder.encode(self.code, forKey: "code")
        aCoder.encode(self.create_time, forKey: "create_time")
        aCoder.encode(self.end_page, forKey: "end_page")
        aCoder.encode(self.format, forKey: "format")
        aCoder.encode(self.id, forKey: "id")
        aCoder.encode(self.is_free, forKey: "is_free")
        aCoder.encode(self.name, forKey: "name")
        aCoder.encode(self.path, forKey: "path")
        aCoder.encode(self.pdf_page, forKey: "pdf_page")
        aCoder.encode(self.pid, forKey: "pid")
        aCoder.encode(self.pname, forKey: "pname")
        aCoder.encode(self.purl, forKey: "purl")
        aCoder.encode(self.start_page, forKey: "start_page")
        aCoder.encode(self.url, forKey: "url")
        aCoder.encode(self.content, forKey: "content")
    }
    
    private var chapterFrames = [CTFrame]() //分页
    
    var pageCount:Int {
        return self.chapterFrames.count
    }
    
    // MARK: -- 更新字体
    
    /// 记录该章使用的字体属性
    private var readAttribute:[String:NSObject] = [:]
    
    /// 更新字体
    func updateFont(isSave:Bool = false) {
        let readAttribute = DZMReadConfigure.shared().readAttribute()
        self.readAttribute = readAttribute
        self.paginate(bounds: GetReadViewFrame())
    }
    
    private var epubContents = [CJEpubChapterContentInfo]() //章节内容，多种类型，最终拼接成章节内容
    private var images = [CJEpubChapterImageInfo]() //章节对应的插图
    
    private var subStrings = [String]() //记录书签使用，分页的时候生成
    
    //填充html
    private func parthHTMLContent() {
        var content = NSString(string: self.content).convertingHTMLToPlainText()!
        content = content.filterTxt()
        
        //解析
        var contents = [CJEpubChapterContentInfo]()
        var images = [CJEpubChapterImageInfo]()
        
        let scanner = Scanner(string: content)
        var targetContent = ""
        
        while !scanner.isAtEnd {
            if scanner.scanString("<img>", into: nil) {
                
                var temp:NSString? = ""
                scanner.scanUpTo("</img>", into: &temp)
                
                let contentInfo = CJEpubChapterContentInfo()
                contentInfo.type = .img
                
                //获取图片大小
                if let imageUrlNSString = temp {
                    let imageUrlString = String(imageUrlNSString)
                    if let imageSize = CJImageDownloader.shared.fetchImage(imageUrl: imageUrlString)?.size {
                        
                        let readViewSize = GetReadViewFrame().size
                        
                        var width = imageSize.width
                        var height = imageSize.height
                        
                        if width > readViewSize.width {
                            height = height * (readViewSize.width / width)
                            width = readViewSize.width
                        }
                        
                        if height > readViewSize.height {
                            width = width * (readViewSize.height / height)
                            height = readViewSize.height
                        }
                        
                        contentInfo.width = width
                        contentInfo.height = height
                    }
                }
                
                contentInfo.content = String(temp!)
                
                contents.append(contentInfo)
                
                //存储图片信息
                let imageInfo = CJEpubChapterImageInfo()
                imageInfo.url = String(temp!)
                imageInfo.position = targetContent.length
                images.append(imageInfo)
                
                scanner.scanString("</img>", into: nil)
            } else {
                var temp:NSString? = ""
                if scanner.scanUpTo("<img>", into: &temp) {
                    var con = ""
                    if let temp_ = temp {
                        con = String(temp_)
                    }
                    
                    let contentInfo = CJEpubChapterContentInfo()
                    contentInfo.type = .txt
                    contentInfo.content = String(temp!)
                    contents.append(contentInfo)
                    
                    targetContent += con
                }
            }
        }
        
        self.epubContents = contents
        self.images = images
    }
    
    //获取frame
    func frameFor(page:Int) -> CTFrame? {
        if page >= 0 && page < self.chapterFrames.count {
            return self.chapterFrames[page]
        } else {
            return nil
        }
    }
    
    //获取对应page的内容，mark使用
    func contentFor(page:Int) -> String {
        if page >= 0 && page < self.subStrings.count {
            return self.subStrings[page]
        } else {
            return ""
        }
    }
    
    //分页
    private func paginate(bounds:CGRect) {
        
        let attrString = NSMutableAttributedString()
        for content in self.epubContents {
            switch content.type {
            case .txt:
                //解析文本
                let attr = self.readAttribute
                let subString = NSMutableAttributedString(string: content.content, attributes: attr)
                attrString.append(subString)
            case .img:
                
                //如果没有图片宽高，则读取本地
                if !content.content.isEmpty && content.width == 0 && content.height == 0 {
                    if let imageSize = CJImageDownloader.shared.fetchImage(imageUrl: content.content)?.size {
                        let readViewSize = GetReadViewFrame().size
                        var width = imageSize.width
                        var height = imageSize.height
                        if width > readViewSize.width {
                            height = height * (readViewSize.width / width)
                            width = readViewSize.width
                        }
                        if height > readViewSize.height {
                            width = width * (readViewSize.height / height)
                            height = readViewSize.height
                        }
                        content.width = width
                        content.height = height
                    }
                }
                
                //解析图片
                var imageCallback = CTRunDelegateCallbacks(version: kCTRunDelegateVersion1, dealloc: { (refCon) in
                    
                }, getAscent: {(refCon) -> CGFloat in
                    //高度
                    let opaquePtr = OpaquePointer(refCon)
                    let contextPtr = UnsafeMutablePointer<DZMReadContentInfo>(opaquePtr)
                    let contentInfo = contextPtr.pointee
                    let height = contentInfo.height
                    return height
                }, getDescent: { (refCon) -> CGFloat in
                    return 0  //返回底部距离
                }, getWidth: { (refCon) -> CGFloat in
                    //宽度
                    let opaquePtr = OpaquePointer(refCon)
                    let contextPtr = UnsafeMutablePointer<DZMReadContentInfo>(opaquePtr)
                    let contentInfo = contextPtr.pointee
                    let width = contentInfo.width
                    return width
                })
                
                var contentInfo = content
                
                let runDelegate = CTRunDelegateCreate(&imageCallback, &contentInfo)!
                let subString = NSMutableAttributedString(string: "\n")  // 空格用于给图片留位置
                subString.addAttribute(kCTRunDelegateAttributeName as String, value: runDelegate, range: NSMakeRange(0, 1))  //rundelegate  占一个位置
                subString.addAttribute("imagePath", value: contentInfo.content, range: NSMakeRange(0, 1))//添加属性，在CTRun中可以识别出这个字符是图片
                attrString.append(subString)
            }
        }
        
        let setterRef = CTFramesetterCreateWithAttributedString(attrString)
        let pathRef = CGPath(rect: bounds, transform: nil)
        
        let frameRef = CTFramesetterCreateFrame(setterRef, CFRange(location: 0, length: 0), pathRef, nil)
        
        var rang1 = CTFrameGetVisibleStringRange(frameRef)
        let rang2 = CTFrameGetStringRange(frameRef)
        
        var frames = [CTFrame]()
        
        var subContents = [String]() //记录书签使用
        let normalString = attrString.string //记录书签使用
        
        if rang1.length + rang1.location == rang2.length + rang2.location {
            let subFrameRef = CTFramesetterCreateFrame(setterRef,CFRange(location: rang1.location, length: 0), pathRef, nil)
            let range = CTFrameGetVisibleStringRange(subFrameRef)
            rang1 = CFRange(location: range.location + range.length,length: 0)
            frames.append(subFrameRef)
            
            let subString = normalString.substring(NSRange(location: range.location, length: range.length))//记录书签使用
            subContents.append(subString) //记录书签使用
        } else {
            while rang1.length + rang1.location < rang2.location + rang2.length {
                let subFrameRef = CTFramesetterCreateFrame(setterRef,CFRange(location: rang1.location, length: 0), pathRef, nil)
                let range = CTFrameGetVisibleStringRange(subFrameRef)
                rang1 = CFRange(location: range.location + range.length,length: 0)
                frames.append(subFrameRef)
                
                let subString = normalString.substring(NSRange(location: range.location, length: range.length))//记录书签使用
                subContents.append(subString) //记录书签使用
            }
        }
        
        self.subStrings = subContents //记录书签使用
        
        self.chapterFrames = frames
    }
}

class CJEpubChapterContentInfo:NSObject {
    enum InfoType {
        case txt
        case img
    }
    
    var type = InfoType.txt
    var content = ""
    
    var width:CGFloat = 0
    var height:CGFloat = 0
}

class CJEpubChapterImageInfo:NSObject {
    var url = "" //图片链接
    var imageRect = CGRect.zero //图片位置
    var position = 0
}

