
#import "CDVBookRead.h"
#import <CJBookReader.framework/Headers/CJBookReader.h>

@interface CDVBookRead()
@property(nonatomic,strong) id<NSObject> notificationHandle;
@end

@implementation CDVBookRead

- (void)reader:(CDVInvokedUrlCommand*)command{
    [self.commandDelegate runInBackground:^{
        NSDictionary *paras = command.arguments[0];
        NSString *bookid = [paras objectForKey:@"bookid"];
        NSString *booktype = [paras objectForKey:@"booktype"];
        NSString *token = [paras objectForKey:@"token"];
        NSString *chapterId = [paras objectForKey:@"chid"];
        NSString *userid = [paras objectForKey:@"userid"];
        NSString *ctxpath = [paras objectForKey:@"ctxPath"];
        
        if (chapterId == [NSNull null]) {
            chapterId = nil;
        }
        
        CJUserInfo.shared.userId = userid;
        CJUserInfo.shared.token = token;
        CJUserInfo.shared.baseUrl = ctxpath;
        
        dispatch_async(dispatch_get_main_queue(), ^{
            DZMReadController *controller = [[DZMReadController alloc] initWithBookId:bookid bookType:booktype chapterId:chapterId];
            
            [[UIApplication sharedApplication].keyWindow.rootViewController showViewController:controller sender:nil];
        });
    }];
    
    if (self.notificationHandle) {
        [[NSNotificationCenter defaultCenter] removeObserver:self.notificationHandle];
        self.notificationHandle = nil;
    }
    
    //添加消息监听，接收原生发起的js调用
    self.notificationHandle = [[NSNotificationCenter defaultCenter] addObserverForName:@"exeJS" object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification * _Nonnull note) {
        NSString *jsString = note.object;
        if ([jsString isKindOfClass:[NSString class]]) {
            [self.commandDelegate evalJs:jsString];
        }
    }];
}

@end




//
//
//#import "CDVBookRead.h"
//
//@implementation CDVBookRead
//
//- (void)reader:(CDVInvokedUrlCommand*)command{
//
//
//}
//
//@end
//








